import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ExternalLink, ArrowRight } from 'lucide-react';
import { ProjectCard } from './ProjectCard';
import { CaseStudy } from './CaseStudy';
import { GoldAccountMockup } from './GoldAccountMockup';
import { LendingEngineMockup } from './LendingEngineMockup';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  thumbnailComponent?: React.ReactNode;
  tags: string[];
  caseStudy: {
    challenge: string;
    solution: string;
    impact: string[];
    process: {
      title: string;
      description: string;
    }[];
    images: string[];
  };
}

export function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-35421ff0/projects`,
        {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        }
      );

      const data = await response.json();
      setProjects(data.projects || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <section id="work" className="py-32 px-6 bg-black">
        <div className="max-w-7xl mx-auto text-center text-gray-400">
          Loading projects...
        </div>
      </section>
    );
  }

  return (
    <section id="work" className="py-32 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-5xl md:text-6xl mb-4">
            Selected <span className="text-blue-500">Work</span>
          </h2>
          <p className="text-xl text-gray-400">
            Case studies showcasing impactful design solutions
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={project.id}
              project={project}
              index={index}
              onClick={() => setSelectedProject(project)}
            />
          ))}
        </div>
      </div>

      {/* Case Study Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-50 overflow-y-auto"
            onClick={() => setSelectedProject(null)}
          >
            <div className="min-h-screen py-12 px-6">
              <div className="max-w-5xl mx-auto">
                <motion.button
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="fixed top-6 right-6 p-3 bg-gray-900/90 backdrop-blur-sm hover:bg-gray-800 rounded-full transition-colors shadow-lg"
                  onClick={() => setSelectedProject(null)}
                >
                  <X className="w-6 h-6" />
                </motion.button>

                <CaseStudy project={selectedProject} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}