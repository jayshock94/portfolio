import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { LogOut, Plus, Edit, Trash2, Save, X, Eye } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { projectId as supabaseProjectId, publicAnonKey } from '../utils/supabase/info';

interface Project {
  id?: string;
  title: string;
  category: string;
  description: string;
  tags: string[];
  caseStudy: {
    challenge: string;
    solution: string;
    impact: string[];
    process: { title: string; description: string }[];
  };
  image?: string;
}

interface ContactInfo {
  email: string;
  phone: string;
  location: string;
}

interface SocialLink {
  id: string;
  platform: string;
  url: string;
  visible: boolean;
}

interface AdminDashboardProps {
  accessToken: string;
  onLogout: () => void;
}

export function AdminDashboard({ accessToken, onLogout }: AdminDashboardProps) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [contact, setContact] = useState<ContactInfo>({ email: '', phone: '', location: '' });
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([]);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isPublicView, setIsPublicView] = useState(false);
  
  // Settings state
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Add error logging for debugging
      if (!supabaseProjectId || !publicAnonKey) {
        console.error('Missing Supabase credentials:', { supabaseProjectId, publicAnonKey });
        toast.error('Configuration error: Missing Supabase credentials');
        setLoading(false);
        return;
      }

      const [projectsRes, contactRes, socialRes] = await Promise.all([
        fetch(`https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/projects`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        }),
        fetch(`https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/contact`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        }),
        fetch(`https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/social-links`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        })
      ]);

      const projectsData = await projectsRes.json();
      const contactData = await contactRes.json();
      const socialData = await socialRes.json();

      setProjects(projectsData.projects || []);
      setContact(contactData.contact || { email: '', phone: '', location: '' });
      setSocialLinks(socialData.socialLinks || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProject = async (project: Project) => {
    try {
      const url = project.id
        ? `https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/projects/${project.id}`
        : `https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/projects`;
      
      const method = project.id ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify(project)
      });

      if (!response.ok) {
        throw new Error('Failed to save project');
      }

      toast.success(project.id ? 'Project updated!' : 'Project created!');
      await fetchData();
      setShowProjectForm(false);
      setEditingProject(null);
    } catch (error) {
      console.error('Error saving project:', error);
      toast.error('Failed to save project');
    }
  };

  const handleDeleteProject = async (id: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return;

    try {
      const response = await fetch(`https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/projects/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });

      if (!response.ok) {
        throw new Error('Failed to delete project');
      }

      toast.success('Project deleted!');
      await fetchData();
    } catch (error) {
      console.error('Error deleting project:', error);
      toast.error('Failed to delete project');
    }
  };

  const handleSaveContact = async () => {
    try {
      const response = await fetch(`https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/contact`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify(contact)
      });

      if (!response.ok) {
        throw new Error('Failed to save contact info');
      }

      toast.success('Contact info updated!');
    } catch (error) {
      console.error('Error saving contact:', error);
      toast.error('Failed to save contact info');
    }
  };

  const handleSaveSocialLinks = async () => {
    try {
      const response = await fetch(`https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/social-links`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify(socialLinks)
      });

      if (!response.ok) {
        throw new Error('Failed to save social links');
      }

      toast.success('Social links updated!');
    } catch (error) {
      console.error('Error saving social links:', error);
      toast.error('Failed to save social links');
    }
  };

  const handleUpdateCredentials = async () => {
    try {
      // Validation
      if (!newEmail && !newPassword) {
        toast.error('Please enter new email or password');
        return;
      }

      if (newPassword && newPassword !== confirmPassword) {
        toast.error('Passwords do not match');
        return;
      }

      if (newPassword && newPassword.length < 6) {
        toast.error('Password must be at least 6 characters');
        return;
      }

      const response = await fetch(`https://${supabaseProjectId}.supabase.co/functions/v1/make-server-35421ff0/admin/credentials`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ 
          newEmail: newEmail || undefined, 
          newPassword: newPassword || undefined 
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to update credentials');
      }

      toast.success('Credentials updated! Please log in again with your new credentials.');
      
      // Clear form
      setNewEmail('');
      setNewPassword('');
      setConfirmPassword('');
      
      // Log out after a short delay
      setTimeout(() => {
        handleLogout();
      }, 2000);
    } catch (error: any) {
      console.error('Error updating credentials:', error);
      toast.error(error.message || 'Failed to update credentials');
    }
  };

  const handleLogout = async () => {
    onLogout();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (isPublicView) {
    return (
      <div className="relative">
        <div className="fixed top-4 right-4 z-50 flex gap-2">
          <Button
            onClick={() => setIsPublicView(false)}
            className="bg-zinc-800 hover:bg-zinc-700 text-white"
          >
            Back to Admin
          </Button>
        </div>
        {/* This would render the public portfolio view */}
        <div className="min-h-screen bg-black text-white p-8">
          <h1 className="text-center mb-8">Public Portfolio View</h1>
          <p className="text-zinc-400 text-center">This is how your portfolio looks to visitors</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="mb-2">Portfolio Admin</h1>
            <p className="text-zinc-400">Manage your projects and content</p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => setIsPublicView(true)}
              variant="outline"
              className="border-zinc-700 hover:bg-zinc-800 hover:border-zinc-600 !bg-transparent !text-white transition-all"
            >
              <Eye className="w-4 h-4 mr-2" />
              <span>Preview</span>
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-zinc-700 hover:bg-zinc-800 hover:border-zinc-600 !bg-transparent !text-white transition-all"
            >
              <LogOut className="w-4 h-4 mr-2" />
              <span>Logout</span>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="projects" className="space-y-6">
          <TabsList className="bg-zinc-900 border border-zinc-800">
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="contact">Contact Info</TabsTrigger>
            <TabsTrigger value="social">Social Links</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2>Projects ({projects.length})</h2>
              <Button
                onClick={() => {
                  setEditingProject({
                    title: '',
                    category: '',
                    description: '',
                    tags: [],
                    caseStudy: {
                      challenge: '',
                      solution: '',
                      impact: [],
                      process: []
                    }
                  });
                  setShowProjectForm(true);
                }}
                className="bg-gradient-to-r from-blue-500 to-purple-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Project
              </Button>
            </div>

            {showProjectForm ? (
              <ProjectForm
                project={editingProject!}
                onSave={handleSaveProject}
                onCancel={() => {
                  setShowProjectForm(false);
                  setEditingProject(null);
                }}
              />
            ) : (
              <div className="grid gap-4">
                {projects.map((project) => (
                  <Card key={project.id} className="bg-zinc-900 border-zinc-800 p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-white mb-1">{project.title}</h3>
                        <p className="text-zinc-400 text-sm mb-2">{project.category}</p>
                        <p className="text-zinc-500 text-sm">{project.description}</p>
                        <div className="flex flex-wrap gap-2 mt-3">
                          {project.tags?.map((tag, i) => (
                            <span key={i} className="px-2 py-1 bg-blue-500/10 text-blue-400 rounded text-xs">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-zinc-700"
                          onClick={() => {
                            setEditingProject(project);
                            setShowProjectForm(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                          onClick={() => handleDeleteProject(project.id!)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Contact Tab */}
          <TabsContent value="contact">
            <Card className="bg-zinc-900 border-zinc-800 p-6">
              <h2 className="mb-6">Contact Information</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="email" className="text-zinc-300">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={contact.email}
                    onChange={(e) => setContact({ ...contact, email: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="phone" className="text-zinc-300">Phone</Label>
                  <Input
                    id="phone"
                    value={contact.phone}
                    onChange={(e) => setContact({ ...contact, phone: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="location" className="text-zinc-300">Location</Label>
                  <Input
                    id="location"
                    value={contact.location}
                    onChange={(e) => setContact({ ...contact, location: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white mt-2"
                  />
                </div>
                <Button
                  onClick={handleSaveContact}
                  className="bg-gradient-to-r from-blue-500 to-purple-600"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Contact Info
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Social Links Tab */}
          <TabsContent value="social">
            <Card className="bg-zinc-900 border-zinc-800 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2>Social Media Links</h2>
                <Button
                  onClick={() => {
                    setSocialLinks([
                      ...socialLinks,
                      { id: Date.now().toString(), platform: '', url: '', visible: true }
                    ]);
                  }}
                  variant="outline"
                  className="border-zinc-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Link
                </Button>
              </div>
              <div className="space-y-4">
                {socialLinks.map((link, index) => (
                  <div key={link.id} className="flex gap-4 items-end">
                    <div className="flex-1">
                      <Label className="text-zinc-300">Platform</Label>
                      <Input
                        value={link.platform}
                        onChange={(e) => {
                          const updated = [...socialLinks];
                          updated[index].platform = e.target.value;
                          setSocialLinks(updated);
                        }}
                        className="bg-zinc-800 border-zinc-700 text-white mt-2"
                        placeholder="LinkedIn"
                      />
                    </div>
                    <div className="flex-1">
                      <Label className="text-zinc-300">URL</Label>
                      <Input
                        value={link.url}
                        onChange={(e) => {
                          const updated = [...socialLinks];
                          updated[index].url = e.target.value;
                          setSocialLinks(updated);
                        }}
                        className="bg-zinc-800 border-zinc-700 text-white mt-2"
                        placeholder="https://linkedin.com/in/..."
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <Label className="text-zinc-300">Visible</Label>
                      <Switch
                        checked={link.visible}
                        onCheckedChange={(checked) => {
                          const updated = [...socialLinks];
                          updated[index].visible = checked;
                          setSocialLinks(updated);
                        }}
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-red-500/50 text-red-400"
                      onClick={() => {
                        setSocialLinks(socialLinks.filter((_, i) => i !== index));
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <Button
                onClick={handleSaveSocialLinks}
                className="bg-gradient-to-r from-blue-500 to-purple-600 mt-6"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Social Links
              </Button>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card className="bg-zinc-900 border-zinc-800 p-6">
              <h2 className="mb-2">Admin Login Settings</h2>
              <p className="text-zinc-400 text-sm mb-6">
                Update your login credentials. You'll be logged out after saving and will need to log in again with your new credentials.
              </p>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="newEmail" className="text-zinc-300">New Email (optional)</Label>
                  <Input
                    id="newEmail"
                    type="email"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white mt-2"
                    placeholder="Leave blank to keep current email"
                  />
                </div>
                <div>
                  <Label htmlFor="newPassword" className="text-zinc-300">New Password (optional)</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white mt-2"
                    placeholder="Leave blank to keep current password"
                  />
                </div>
                <div>
                  <Label htmlFor="confirmPassword" className="text-zinc-300">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white mt-2"
                    placeholder="Re-enter new password"
                    disabled={!newPassword}
                  />
                </div>
                <Button
                  onClick={handleUpdateCredentials}
                  className="bg-gradient-to-r from-blue-500 to-purple-600"
                  disabled={!newEmail && !newPassword}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Update Credentials
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function ProjectForm({ project, onSave, onCancel }: {
  project: Project;
  onSave: (project: Project) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState<Project>(project);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Card className="bg-zinc-900 border-zinc-800 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-white">{formData.id ? 'Edit Project' : 'New Project'}</h3>
        <Button variant="ghost" onClick={onCancel}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="title" className="text-zinc-300">Title</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            required
          />
        </div>

        <div>
          <Label htmlFor="category" className="text-zinc-300">Category</Label>
          <Input
            id="category"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            required
          />
        </div>

        <div>
          <Label htmlFor="description" className="text-zinc-300">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            rows={3}
            required
          />
        </div>

        <div>
          <Label htmlFor="image" className="text-zinc-300">Image URL</Label>
          <Input
            id="image"
            value={formData.image || ''}
            onChange={(e) => setFormData({ ...formData, image: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            placeholder="https://images.unsplash.com/..."
          />
          <p className="text-zinc-500 text-xs mt-1">Use an Unsplash or other image URL</p>
        </div>

        <div>
          <Label htmlFor="tags" className="text-zinc-300">Tags (comma-separated)</Label>
          <Input
            id="tags"
            value={formData.tags?.join(', ') || ''}
            onChange={(e) => setFormData({ ...formData, tags: e.target.value.split(',').map(t => t.trim()) })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            placeholder="Mobile, Material 3, Premium Banking"
          />
        </div>

        <div>
          <Label htmlFor="challenge" className="text-zinc-300">Challenge</Label>
          <Textarea
            id="challenge"
            value={formData.caseStudy.challenge}
            onChange={(e) => setFormData({
              ...formData,
              caseStudy: { ...formData.caseStudy, challenge: e.target.value }
            })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            rows={3}
            required
          />
        </div>

        <div>
          <Label htmlFor="solution" className="text-zinc-300">Solution</Label>
          <Textarea
            id="solution"
            value={formData.caseStudy.solution}
            onChange={(e) => setFormData({
              ...formData,
              caseStudy: { ...formData.caseStudy, solution: e.target.value }
            })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            rows={3}
            required
          />
        </div>

        <div>
          <Label htmlFor="impact" className="text-zinc-300">Impact Points (one per line)</Label>
          <Textarea
            id="impact"
            value={formData.caseStudy.impact?.join('\n') || ''}
            onChange={(e) => setFormData({
              ...formData,
              caseStudy: { ...formData.caseStudy, impact: e.target.value.split('\n').filter(l => l.trim()) }
            })}
            className="bg-zinc-800 border-zinc-700 text-white mt-2"
            rows={4}
            placeholder="89% satisfaction rate&#10;54% increase in feature adoption"
          />
        </div>

        <div className="flex gap-2 pt-4">
          <Button
            type="submit"
            className="bg-gradient-to-r from-blue-500 to-purple-600"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Project
          </Button>
          <Button type="button" variant="outline" className="border-zinc-700" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </form>
    </Card>
  );
}