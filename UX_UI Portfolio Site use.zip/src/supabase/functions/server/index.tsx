import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Initialize default admin user on startup
async function initializeAdminUser() {
  try {
    const defaultEmail = 'jayshock44@gmail.com';
    const defaultPassword = 'Dreambig44!';
    
    // Check if admin user exists
    const { data: users } = await supabase.auth.admin.listUsers();
    const adminExists = users?.users?.some(u => u.email === defaultEmail);
    
    if (!adminExists) {
      console.log('Creating default admin user...');
      const { data, error } = await supabase.auth.admin.createUser({
        email: defaultEmail,
        password: defaultPassword,
        email_confirm: true
      });
      
      if (error) {
        console.error('Failed to create admin user:', error.message);
      } else {
        console.log('Default admin user created successfully');
      }
    } else {
      console.log('Admin user already exists');
    }
  } catch (error) {
    console.error('Error initializing admin user:', error);
  }
}

// Initialize default projects if none exist
async function initializeDefaultProjects() {
  try {
    const existingProjects = await kv.get('projects');
    
    if (!existingProjects || existingProjects.length === 0) {
      console.log('Initializing default projects...');
      
      const defaultProjects = [
        {
          id: '1',
          title: 'Gold Account Center',
          category: 'Mobile App',
          description: 'Premium banking experience using Material 3 design system for elite account holders',
          image: 'https://images.unsplash.com/photo-1631005551863-8168afd249e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwY3JlZGl0JTIwY2FyZCUyMHBob25lJTIwbW9ja3VwfGVufDF8fHx8MTc2NDA0NzA1NXww&ixlib=rb-4.1.0&q=80&w=1080',
          tags: ['Mobile', 'Material 3', 'Premium Banking'],
          caseStudy: {
            challenge: 'Elite banking customers expected a premium digital experience that matched their high-value account status. The existing app felt generic and didn\'t reflect the exclusive benefits and personalized service that Gold Account holders received. Navigation was cluttered and key account features were buried deep in menus.',
            solution: 'Designed a dedicated Gold Account Center using Material 3 design principles, featuring a sophisticated interface with premium visual language, personalized dashboard, quick access to concierge services, and elegant animations. The design emphasizes clarity, luxury, and effortless access to exclusive benefits.',
            impact: [
              '89% satisfaction rate among Gold Account holders',
              '54% increase in digital feature adoption',
              '67% reduction in customer service calls',
              'Helped increase Gold Account signups by 41%'
            ],
            process: [
              {
                title: 'User Research & Stakeholder Alignment',
                description: 'Conducted interviews with Gold Account holders to understand their expectations and pain points. Collaborated with relationship managers and the banking team to identify key features that would differentiate the premium experience.'
              },
              {
                title: 'Material 3 Design System Implementation',
                description: 'Applied Material 3 design principles with a premium twist - custom color palette emphasizing gold accents, elevated surfaces with sophisticated depth, and refined typography. Created a component library that balanced Google\'s design language with luxury brand expectations.'
              },
              {
                title: 'Information Architecture',
                description: 'Restructured the account center around customer needs: quick access to account summary, one-tap access to concierge, prominent display of rewards and benefits, and streamlined transaction flows. Prioritized features based on usage data and customer feedback.'
              },
              {
                title: 'Visual Design & Prototyping',
                description: 'Crafted a polished interface with premium materials, subtle animations, and delightful micro-interactions. Created high-fidelity prototypes in Figma to test flows with actual Gold Account customers before development.'
              },
              {
                title: 'Testing & Refinement',
                description: 'Conducted usability testing sessions with target users, gathering feedback on the premium feel, ease of navigation, and feature discoverability. Iterated on visual hierarchy and interaction patterns based on real user behavior.'
              }
            ],
            images: []
          },
          createdAt: new Date().toISOString()
        },
        {
          id: '2',
          title: 'Lending Engine Services',
          category: 'Web Application',
          description: 'Enterprise loan management platform streamlining customer servicing and payment operations',
          image: 'https://images.unsplash.com/photo-1705508216613-be1715a31212?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW50ZWNoJTIwZGFzaGJvYXJkJTIwbGFwdG9wfGVufDF8fHx8MTc2NDA0NzA1OXww&ixlib=rb-4.1.0&q=80&w=1080',
          tags: ['Web', 'Lending', 'Enterprise', 'Dashboard'],
          caseStudy: {
            challenge: 'Loan servicing teams were juggling multiple legacy systems to manage customer accounts, process payments, and track loan history. This fragmented approach led to errors, slow response times, and poor customer experience. Support staff needed 10+ minutes just to locate basic customer information across different platforms.',
            solution: 'Designed a unified loan servicing dashboard that consolidates all customer data, payment processing, and loan history into a single, intuitive interface. Created a flexible sidebar with key customer information always visible, implemented smart search and filtering, and designed streamlined workflows for common tasks like payment processing and account updates.',
            impact: [
              '73% reduction in average handling time',
              '91% improvement in first-call resolution',
              '58% decrease in processing errors',
              'Saved the company $2.4M annually in operational costs'
            ],
            process: [
              {
                title: 'Stakeholder & User Research',
                description: 'Shadowed loan servicing representatives and interviewed team leads to understand daily workflows and pain points. Mapped out all the systems they were using and identified the most critical information needed for each task type.'
              },
              {
                title: 'Information Architecture',
                description: 'Reorganized data hierarchy around customer-centric views rather than system-centric views. Designed a persistent sidebar with customer context and a main content area that adapts based on the selected task (payments, loan info, history, etc.).'
              },
              {
                title: 'Workflow Optimization',
                description: 'Streamlined common tasks like payment processing, payment scheduling, and account inquiries. Reduced multi-step processes across systems into single-screen workflows with inline validation and smart defaults.'
              },
              {
                title: 'Visual Design & Component Library',
                description: 'Created a professional, scannable interface with clear data hierarchy. Built a component library with data tables, forms, and status indicators optimized for high-volume data entry and scanning tasks.'
              },
              {
                title: 'Usability Testing & Iteration',
                description: 'Conducted task-based usability testing with loan servicing reps. Refined the interface based on speed metrics and error rates. Iterated on table layouts, search functionality, and payment workflows until we achieved target efficiency gains.'
              }
            ],
            images: []
          },
          createdAt: new Date().toISOString()
        },
        {
          id: '3',
          title: 'Roost',
          category: 'Mobile App',
          description: 'Outdoor adventure planning platform for hiking, camping, and canyoneering expeditions',
          image: 'https://images.unsplash.com/photo-1552224106-8edd485eff51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWtpbmclMjBtb3VudGFpbnMlMjBhZHZlbnR1cmUlMjBwaG9uZSUyMGFwcHxlbnwxfHx8fDE3NjQwNDY5MzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
          tags: ['Mobile', 'Outdoor', 'Adventure', 'Social', 'Planning'],
          caseStudy: {
            challenge: 'Planning outdoor adventures like hiking, camping, and canyoneering trips involves coordinating multiple people, tracking weather conditions, managing gear lists, sharing logistics, and handling safety waivers. Groups were using a fragmented mix of group chats, weather apps, shared documents, and email to coordinate trips, leading to miscommunication and critical details getting lost.',
            solution: 'Created Roost, an all-in-one adventure planning app that consolidates trip coordination into a single platform. Built features for real-time weather updates, group photo sharing, digital waiver signing, detailed itinerary building, and group messaging. Designed the experience to be intuitive enough for casual hikers while robust enough for serious expeditions.',
            impact: [
              '12K+ active users in first 6 months',
              'Used for 2,500+ outdoor expeditions',
              '87% of users say it improved trip coordination',
              '4.7 star rating on app stores'
            ],
            process: [
              {
                title: 'User Research & Discovery',
                description: 'Interviewed outdoor enthusiasts, hiking groups, and adventure guides to understand their trip planning workflows. Identified that coordination overhead was preventing people from going on adventures as often as they wanted. Safety concerns and waiver management emerged as critical needs for group organizers.'
              },
              {
                title: 'Feature Prioritization',
                description: 'Mapped out all potential features and prioritized based on user pain points and frequency of use. Decided to focus V1 on core trip planning (itinerary, weather, participant management) before expanding to social features like photo sharing and activity feeds.'
              },
              {
                title: 'Information Architecture',
                description: 'Organized the app around "Trips" as the central concept, with each trip containing all relevant information: participants, itinerary, weather forecasts, photos, waivers, and chat. Designed navigation to make it easy to switch between upcoming trips and past adventures.'
              },
              {
                title: 'Visual Design & Prototyping',
                description: 'Created a rugged yet modern visual language inspired by topographic maps and outdoor gear. Used earthy colors, bold typography, and clean layouts that work well in various lighting conditions (since users often check the app outdoors). Built interactive prototypes to test trip creation and participant invitation flows.'
              },
              {
                title: 'Beta Testing & Iteration',
                description: 'Launched beta with local hiking and climbing groups. Gathered feedback during actual trips about what features were most valuable and what was missing. Refined the weather integration, added offline mode for areas with limited service, and improved the photo sharing experience based on user requests.'
              }
            ],
            images: []
          },
          createdAt: new Date().toISOString()
        }
      ];
      
      await kv.set('projects', defaultProjects);
      console.log('Default projects initialized');
    } else {
      console.log('Projects already exist');
    }
  } catch (error) {
    console.error('Error initializing default projects:', error);
  }
}

// Initialize admin and projects on startup
initializeAdminUser();
initializeDefaultProjects();

// Auth Routes
app.post('/make-server-35421ff0/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Error during user signup: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.log(`Unexpected error during signup: ${error}`);
    return c.json({ error: 'Failed to create user' }, 500);
  }
});

app.post('/make-server-35421ff0/login', async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error || !data.session) {
      console.log(`Login error: ${error?.message || 'No session returned'}`);
      return c.json({ error: error?.message || 'Login failed' }, 401);
    }

    return c.json({ 
      success: true, 
      accessToken: data.session.access_token,
      user: data.user 
    });
  } catch (error) {
    console.log(`Unexpected error during login: ${error}`);
    return c.json({ error: 'Login failed' }, 500);
  }
});

app.post('/make-server-35421ff0/verify-session', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ valid: false }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ valid: false }, 401);
    }

    return c.json({ valid: true, user });
  } catch (error) {
    console.log(`Session verification error: ${error}`);
    return c.json({ valid: false }, 500);
  }
});

// Projects Routes
app.get('/make-server-35421ff0/projects', async (c) => {
  try {
    const projects = await kv.get('projects') || [];
    return c.json({ projects });
  } catch (error) {
    console.log(`Error fetching projects: ${error}`);
    return c.json({ error: 'Failed to fetch projects' }, 500);
  }
});

app.post('/make-server-35421ff0/projects', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const project = await c.req.json();
    const projects = await kv.get('projects') || [];
    
    const newProject = {
      ...project,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    
    projects.push(newProject);
    await kv.set('projects', projects);
    
    return c.json({ success: true, project: newProject });
  } catch (error) {
    console.log(`Error creating project: ${error}`);
    return c.json({ error: 'Failed to create project' }, 500);
  }
});

app.put('/make-server-35421ff0/projects/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const id = c.req.param('id');
    const updates = await c.req.json();
    const projects = await kv.get('projects') || [];
    
    const index = projects.findIndex((p: any) => p.id === id);
    if (index === -1) {
      return c.json({ error: 'Project not found' }, 404);
    }
    
    projects[index] = { ...projects[index], ...updates, updatedAt: new Date().toISOString() };
    await kv.set('projects', projects);
    
    return c.json({ success: true, project: projects[index] });
  } catch (error) {
    console.log(`Error updating project: ${error}`);
    return c.json({ error: 'Failed to update project' }, 500);
  }
});

app.delete('/make-server-35421ff0/projects/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const id = c.req.param('id');
    const projects = await kv.get('projects') || [];
    
    const filtered = projects.filter((p: any) => p.id !== id);
    await kv.set('projects', filtered);
    
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error deleting project: ${error}`);
    return c.json({ error: 'Failed to delete project' }, 500);
  }
});

// Contact Info Routes
app.get('/make-server-35421ff0/contact', async (c) => {
  try {
    const contact = await kv.get('contact') || {
      email: 'jay@jayshock.design',
      phone: '',
      location: 'San Francisco, CA'
    };
    return c.json({ contact });
  } catch (error) {
    console.log(`Error fetching contact info: ${error}`);
    return c.json({ error: 'Failed to fetch contact info' }, 500);
  }
});

app.put('/make-server-35421ff0/contact', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const contact = await c.req.json();
    await kv.set('contact', contact);
    
    return c.json({ success: true, contact });
  } catch (error) {
    console.log(`Error updating contact info: ${error}`);
    return c.json({ error: 'Failed to update contact info' }, 500);
  }
});

// Social Links Routes
app.get('/make-server-35421ff0/social-links', async (c) => {
  try {
    const socialLinks = await kv.get('social_links') || [
      { id: '1', platform: 'Dribbble', url: 'https://dribbble.com', visible: true },
      { id: '2', platform: 'Behance', url: 'https://behance.net', visible: true },
      { id: '3', platform: 'LinkedIn', url: 'https://linkedin.com', visible: true },
      { id: '4', platform: 'Twitter', url: 'https://twitter.com', visible: true }
    ];
    return c.json({ socialLinks });
  } catch (error) {
    console.log(`Error fetching social links: ${error}`);
    return c.json({ error: 'Failed to fetch social links' }, 500);
  }
});

app.put('/make-server-35421ff0/social-links', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const socialLinks = await c.req.json();
    await kv.set('social_links', socialLinks);
    
    return c.json({ success: true, socialLinks });
  } catch (error) {
    console.log(`Error updating social links: ${error}`);
    return c.json({ error: 'Failed to update social links' }, 500);
  }
});

// Admin Settings Routes
app.put('/make-server-35421ff0/admin/credentials', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { newEmail, newPassword } = await c.req.json();
    
    // Update email if provided
    if (newEmail && newEmail !== user.email) {
      const { error: emailError } = await supabase.auth.admin.updateUserById(
        user.id,
        { email: newEmail }
      );
      
      if (emailError) {
        console.log(`Error updating email: ${emailError.message}`);
        return c.json({ error: 'Failed to update email' }, 400);
      }
    }
    
    // Update password if provided
    if (newPassword) {
      const { error: passwordError } = await supabase.auth.admin.updateUserById(
        user.id,
        { password: newPassword }
      );
      
      if (passwordError) {
        console.log(`Error updating password: ${passwordError.message}`);
        return c.json({ error: 'Failed to update password' }, 400);
      }
    }
    
    return c.json({ success: true, message: 'Credentials updated successfully' });
  } catch (error) {
    console.log(`Error updating admin credentials: ${error}`);
    return c.json({ error: 'Failed to update credentials' }, 500);
  }
});

Deno.serve(app.fetch);