import { useState, useEffect } from 'react';
import { Hero } from './components/Hero';
import { Projects } from './components/Projects';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Navigation } from './components/Navigation';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';
import { Toaster } from './components/ui/sonner';
import { projectId, publicAnonKey } from './utils/supabase/info';

export default function App() {
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkSession();
    
    // Listen for navigation changes
    const handleLocationChange = () => {
      const path = window.location.pathname;
      if (path === '/admin' && accessToken) {
        setIsAdmin(true);
      } else if (path === '/') {
        setIsAdmin(false);
      }
    };
    
    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  const checkSession = async () => {
    try {
      // Check for stored token
      const storedToken = localStorage.getItem('admin_token');
      
      if (storedToken) {
        // Verify token is still valid
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-35421ff0/verify-session`,
          {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${storedToken}` }
          }
        );

        const data = await response.json();
        
        if (data.valid) {
          setAccessToken(storedToken);
          
          // Check if admin route
          const path = window.location.pathname;
          if (path === '/admin') {
            setIsAdmin(true);
          }
        } else {
          localStorage.removeItem('admin_token');
        }
      } else if (window.location.pathname === '/admin') {
        // Not logged in but trying to access admin
        setIsAdmin(true);
      }
    } catch (error) {
      console.error('Session check error:', error);
      localStorage.removeItem('admin_token');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (token: string) => {
    localStorage.setItem('admin_token', token);
    setAccessToken(token);
    setIsAdmin(true);
    window.history.pushState({}, '', '/admin');
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    setAccessToken(null);
    setIsAdmin(false);
    window.history.pushState({}, '', '/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  // Admin routes
  if (isAdmin) {
    if (!accessToken) {
      return (
        <>
          <AdminLogin onLogin={handleLogin} />
          <Toaster />
        </>
      );
    }
    return (
      <>
        <AdminDashboard accessToken={accessToken} onLogout={handleLogout} />
        <Toaster />
      </>
    );
  }

  // Public portfolio
  return (
    <>
      <div className="min-h-screen bg-black text-white">
        <Navigation />
        <Hero />
        <Projects />
        <About />
        <Contact />
        
        {/* Discreet admin login button */}
        <div className="flex justify-center pb-8">
          <button
            onClick={() => {
              setIsAdmin(true);
              window.history.pushState({}, '', '/admin');
            }}
            className="text-zinc-700 hover:text-zinc-500 text-sm px-4 py-2 transition-colors"
          >
            ⚡
          </button>
        </div>
      </div>
      <Toaster />
    </>
  );
}