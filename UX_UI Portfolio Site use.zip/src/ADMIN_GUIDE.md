# Portfolio CMS Admin Guide

## Getting Started

### Accessing the Admin Panel

1. **From the public site**: Click the Settings (⚙️) icon in the top navigation
2. **Direct URL**: Navigate to `/admin` route

### First Time Setup

1. Click "Don't have an account? Sign up"
2. Enter your name, email, and password
3. Click "Create Account" - you'll be automatically logged in
4. Your account is now created and you can manage your portfolio

### Logging In

1. Navigate to `/admin`
2. Enter your email and password
3. Click "Sign In"

## Managing Projects

### Adding a New Project

1. Go to the **Projects** tab
2. Click **Add Project** button
3. Fill in the form:
   - **Title**: Project name (e.g., "Gold Account Center")
   - **Category**: Type of project (e.g., "Mobile App")
   - **Description**: Brief overview of the project
   - **Tags**: Comma-separated keywords (e.g., "Mobile, Material 3, Premium Banking")
   - **Challenge**: What problem did this project solve?
   - **Solution**: How did you solve it?
   - **Impact Points**: One achievement per line (e.g., "89% satisfaction rate")
4. Click **Save Project**

### Editing a Project

1. Find the project in the list
2. Click the **Edit** button (pencil icon)
3. Update the fields you want to change
4. Click **Save Project**

### Deleting a Project

1. Find the project in the list
2. Click the **Delete** button (trash icon)
3. Confirm deletion when prompted

## Managing Contact Information

1. Go to the **Contact Info** tab
2. Update any of the fields:
   - Email address
   - Phone number
   - Location
3. Click **Save Contact Info**

These changes will appear in the Contact section of your public portfolio.

## Managing Social Media Links

### Editing Existing Links

1. Go to the **Social Links** tab
2. Update the platform name or URL
3. Toggle the **Visible** switch to show/hide the link on your portfolio
4. Click **Save Social Links**

### Adding a New Link

1. Click **Add Link** button
2. Enter the platform name (e.g., "LinkedIn", "Dribbble")
3. Enter the full URL (e.g., "https://linkedin.com/in/jayshock")
4. Toggle visibility on/off
5. Click **Save Social Links**

### Removing a Link

1. Click the trash icon next to the link you want to remove
2. Click **Save Social Links**

## Preview Mode

- Click the **Preview** button in the top right to see how your portfolio looks to visitors
- Click **Back to Admin** to return to the dashboard

## Logging Out

- Click the **Logout** button in the top right corner
- You'll be returned to the login page

## Tips

- **Tags**: Use descriptive tags that highlight key technologies or design approaches
- **Impact Points**: Use specific numbers and percentages to demonstrate results
- **Visibility**: Hide social links that aren't ready yet, but keep the data saved
- **Save Often**: Click save after making changes to ensure your data is persisted

## Security Notes

- Keep your admin credentials secure
- Only access the admin panel from trusted devices
- Log out when finished editing
- Your admin account is separate from your public portfolio - visitors can't access it

## Need Help?

If you encounter any issues:
1. Check the browser console for error messages
2. Make sure you're logged in with a valid session
3. Refresh the page if data doesn't appear to update
4. Contact support if problems persist
