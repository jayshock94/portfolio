import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { Project } from './Projects';

interface ProjectCardProps {
  project: Project;
  index: number;
  onClick: () => void;
}

export function ProjectCard({ project, index, onClick }: ProjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      onClick={onClick}
      className="group cursor-pointer relative overflow-hidden bg-gray-900/50 backdrop-blur-sm rounded-3xl hover:shadow-2xl hover:shadow-blue-500/20 transition-all duration-300"
    >
      {/* Image or Component */}
      <div className="aspect-[4/3] overflow-hidden relative rounded-t-3xl">
        {project.thumbnailComponent ? (
          <div className="w-full h-full">
            {project.thumbnailComponent}
          </div>
        ) : (
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent" />
        
        {/* Category badge */}
        <div className="absolute top-4 left-4 px-4 py-2 bg-blue-500 text-white rounded-full text-sm tracking-wider shadow-lg">
          {project.category}
        </div>
      </div>

      {/* Content */}
      <div className="p-8">
        <h3 className="text-2xl mb-2 group-hover:text-blue-400 transition-colors">
          {project.title}
        </h3>
        <p className="text-gray-400 mb-4">
          {project.description}
        </p>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 bg-white/5 text-sm text-gray-400 rounded-full border border-gray-800"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* View Case Study link */}
        <div className="flex items-center gap-2 text-blue-400 group-hover:gap-4 transition-all">
          <span>View Case Study</span>
          <ArrowRight className="w-5 h-5" />
        </div>
      </div>

      {/* Hover effect */}
      <div className="absolute inset-0 border-2 border-blue-500 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none rounded-3xl" />
    </motion.div>
  );
}