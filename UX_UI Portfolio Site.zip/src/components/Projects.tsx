import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ExternalLink, ArrowRight } from 'lucide-react';
import { ProjectCard } from './ProjectCard';
import { CaseStudy } from './CaseStudy';
import { GoldAccountMockup } from './GoldAccountMockup';
import { LendingEngineMockup } from './LendingEngineMockup';

export interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  thumbnailComponent?: React.ReactNode;
  tags: string[];
  caseStudy: {
    challenge: string;
    solution: string;
    impact: string[];
    process: {
      title: string;
      description: string;
    }[];
    images: string[];
  };
}

const projects: Project[] = [
  {
    id: '1',
    title: 'Gold Account Center',
    category: 'Mobile App',
    description: 'Premium banking experience using Material 3 design system for elite account holders',
    image: 'https://images.unsplash.com/photo-1631005551863-8168afd249e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwY3JlZGl0JTIwY2FyZCUyMHBob25lJTIwbW9ja3VwfGVufDF8fHx8MTc2NDA0NzA1NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    tags: ['Mobile', 'Material 3', 'Premium Banking'],
    caseStudy: {
      challenge: 'Elite banking customers expected a premium digital experience that matched their high-value account status. The existing app felt generic and didn\'t reflect the exclusive benefits and personalized service that Gold Account holders received. Navigation was cluttered and key account features were buried deep in menus.',
      solution: 'Designed a dedicated Gold Account Center using Material 3 design principles, featuring a sophisticated interface with premium visual language, personalized dashboard, quick access to concierge services, and elegant animations. The design emphasizes clarity, luxury, and effortless access to exclusive benefits.',
      impact: [
        '89% satisfaction rate among Gold Account holders',
        '54% increase in digital feature adoption',
        '67% reduction in customer service calls',
        'Helped increase Gold Account signups by 41%'
      ],
      process: [
        {
          title: 'User Research & Stakeholder Alignment',
          description: 'Conducted interviews with Gold Account holders to understand their expectations and pain points. Collaborated with relationship managers and the banking team to identify key features that would differentiate the premium experience.'
        },
        {
          title: 'Material 3 Design System Implementation',
          description: 'Applied Material 3 design principles with a premium twist - custom color palette emphasizing gold accents, elevated surfaces with sophisticated depth, and refined typography. Created a component library that balanced Google\'s design language with luxury brand expectations.'
        },
        {
          title: 'Information Architecture',
          description: 'Restructured the account center around customer needs: quick access to account summary, one-tap access to concierge, prominent display of rewards and benefits, and streamlined transaction flows. Prioritized features based on usage data and customer feedback.'
        },
        {
          title: 'Visual Design & Prototyping',
          description: 'Crafted a polished interface with premium materials, subtle animations, and delightful micro-interactions. Created high-fidelity prototypes in Figma to test flows with actual Gold Account customers before development.'
        },
        {
          title: 'Testing & Refinement',
          description: 'Conducted usability testing sessions with target users, gathering feedback on the premium feel, ease of navigation, and feature discoverability. Iterated on visual hierarchy and interaction patterns based on real user behavior.'
        }
      ],
      images: [
        'https://images.unsplash.com/photo-1631005551863-8168afd249e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwY3JlZGl0JTIwY2FyZCUyMHBob25lJTIwbW9ja3VwfGVufDF8fHx8MTc2NDA0NzA1NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        'https://images.unsplash.com/photo-1681826291722-70bd7e9e6fc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5raW5nJTIwbW9iaWxlJTIwYXBwfGVufDF8fHx8MTc2NDAwNzgyNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      ]
    }
  },
  {
    id: '2',
    title: 'Lending Engine Services',
    category: 'Web Application',
    description: 'Enterprise loan management platform streamlining customer servicing and payment operations',
    image: 'https://images.unsplash.com/photo-1705508216613-be1715a31212?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW50ZWNoJTIwZGFzaGJvYXJkJTIwbGFwdG9wfGVufDF8fHx8MTc2NDA0NzA1OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    tags: ['Web', 'Lending', 'Enterprise', 'Dashboard'],
    caseStudy: {
      challenge: 'Loan servicing teams were juggling multiple legacy systems to manage customer accounts, process payments, and track loan history. This fragmented approach led to errors, slow response times, and poor customer experience. Support staff needed 10+ minutes just to locate basic customer information across different platforms.',
      solution: 'Designed a unified loan servicing dashboard that consolidates all customer data, payment processing, and loan history into a single, intuitive interface. Created a flexible sidebar with key customer information always visible, implemented smart search and filtering, and designed streamlined workflows for common tasks like payment processing and account updates.',
      impact: [
        '73% reduction in average handling time',
        '91% improvement in first-call resolution',
        '58% decrease in processing errors',
        'Saved the company $2.4M annually in operational costs'
      ],
      process: [
        {
          title: 'Stakeholder & User Research',
          description: 'Shadowed loan servicing representatives and interviewed team leads to understand daily workflows and pain points. Mapped out all the systems they were using and identified the most critical information needed for each task type.'
        },
        {
          title: 'Information Architecture',
          description: 'Reorganized data hierarchy around customer-centric views rather than system-centric views. Designed a persistent sidebar with customer context and a main content area that adapts based on the selected task (payments, loan info, history, etc.).'
        },
        {
          title: 'Workflow Optimization',
          description: 'Streamlined common tasks like payment processing, payment scheduling, and account inquiries. Reduced multi-step processes across systems into single-screen workflows with inline validation and smart defaults.'
        },
        {
          title: 'Visual Design & Component Library',
          description: 'Created a professional, scannable interface with clear data hierarchy. Built a component library with data tables, forms, and status indicators optimized for high-volume data entry and scanning tasks.'
        },
        {
          title: 'Usability Testing & Iteration',
          description: 'Conducted task-based usability testing with loan servicing reps. Refined the interface based on speed metrics and error rates. Iterated on table layouts, search functionality, and payment workflows until we achieved target efficiency gains.'
        }
      ],
      images: [
        'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&q=80',
        'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&q=80'
      ]
    }
  },
  {
    id: '3',
    title: 'Roost',
    category: 'Mobile App',
    description: 'Outdoor adventure planning platform for hiking, camping, and canyoneering expeditions',
    image: 'https://images.unsplash.com/photo-1552224106-8edd485eff51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWtpbmclMjBtb3VudGFpbnMlMjBhZHZlbnR1cmUlMjBwaG9uZSUyMGFwcHxlbnwxfHx8fDE3NjQwNDY5MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    tags: ['Mobile', 'Outdoor', 'Adventure', 'Social', 'Planning'],
    caseStudy: {
      challenge: 'Planning outdoor adventures like hiking, camping, and canyoneering trips involves coordinating multiple people, tracking weather conditions, managing gear lists, sharing logistics, and handling safety waivers. Groups were using a fragmented mix of group chats, weather apps, shared documents, and email to coordinate trips, leading to miscommunication and critical details getting lost.',
      solution: 'Created Roost, an all-in-one adventure planning app that consolidates trip coordination into a single platform. Built features for real-time weather updates, group photo sharing, digital waiver signing, detailed itinerary building, and group messaging. Designed the experience to be intuitive enough for casual hikers while robust enough for serious expeditions.',
      impact: [
        '12K+ active users in first 6 months',
        'Used for 2,500+ outdoor expeditions',
        '87% of users say it improved trip coordination',
        '4.7 star rating on app stores'
      ],
      process: [
        {
          title: 'User Research & Discovery',
          description: 'Interviewed outdoor enthusiasts, hiking groups, and adventure guides to understand their trip planning workflows. Identified that coordination overhead was preventing people from going on adventures as often as they wanted. Safety concerns and waiver management emerged as critical needs for group organizers.'
        },
        {
          title: 'Feature Prioritization',
          description: 'Mapped out all potential features and prioritized based on user pain points and frequency of use. Decided to focus V1 on core trip planning (itinerary, weather, participant management) before expanding to social features like photo sharing and activity feeds.'
        },
        {
          title: 'Information Architecture',
          description: 'Organized the app around "Trips" as the central concept, with each trip containing all relevant information: participants, itinerary, weather forecasts, photos, waivers, and chat. Designed navigation to make it easy to switch between upcoming trips and past adventures.'
        },
        {
          title: 'Visual Design & Prototyping',
          description: 'Created a rugged yet modern visual language inspired by topographic maps and outdoor gear. Used earthy colors, bold typography, and clean layouts that work well in various lighting conditions (since users often check the app outdoors). Built interactive prototypes to test trip creation and participant invitation flows.'
        },
        {
          title: 'Beta Testing & Iteration',
          description: 'Launched beta with local hiking and climbing groups. Gathered feedback during actual trips about what features were most valuable and what was missing. Refined the weather integration, added offline mode for areas with limited service, and improved the photo sharing experience based on user requests.'
        }
      ],
      images: [
        'https://images.unsplash.com/photo-1552224106-8edd485eff51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWtpbmclMjBtb3VudGFpbnMlMjBhZHZlbnR1cmUlMjBwaG9uZSUyMGFwcHxlbnwxfHx8fDE3NjQwNDY5MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        'https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?w=1200&q=80'
      ]
    }
  },
  {
    id: '4',
    title: 'SaaS Platform Redesign',
    category: 'Web Application',
    description: 'Enterprise project management tool used by teams to collaborate and deliver projects',
    image: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800&q=80',
    tags: ['Web', 'SaaS', 'Enterprise', 'Collaboration'],
    caseStudy: {
      challenge: 'The existing platform was powerful but had accumulated features over years without cohesive UX strategy. New users faced a steep learning curve and teams weren\'t adopting advanced features that could improve their workflow.',
      solution: 'Led a comprehensive redesign focusing on progressive disclosure, contextual help, and intelligent defaults. Restructured navigation around user tasks rather than features. Introduced guided tours and templates to accelerate onboarding.',
      impact: [
        '60% reduction in onboarding time',
        '38% increase in feature adoption',
        '4.5x improvement in NPS score',
        'Reduced churn by 23%'
      ],
      process: [
        {
          title: 'Stakeholder Interviews',
          description: 'Worked with product, engineering, and sales teams to understand business goals and technical constraints. Interviewed power users and admins about their workflows and pain points.'
        },
        {
          title: 'UX Audit',
          description: 'Conducted comprehensive audit of existing flows, identifying inconsistencies, unused features, and areas of friction. Mapped current user journeys and identified optimization opportunities.'
        },
        {
          title: 'Design System',
          description: 'Built a scalable design system with reusable components, consistent patterns, and clear documentation. This enabled faster development and ensured consistency across all features.'
        },
        {
          title: 'Phased Rollout',
          description: 'Worked with engineering to implement changes in phases, gathering feedback at each stage. This allowed us to validate improvements and make adjustments before full deployment.'
        }
      ],
      images: [
        'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=1200&q=80',
        'https://images.unsplash.com/photo-1553877522-43269d4ea984?w=1200&q=80'
      ]
    }
  }
];

export function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <section id="work" className="py-32 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-5xl md:text-6xl mb-4">
            Selected <span className="text-blue-500">Work</span>
          </h2>
          <p className="text-xl text-gray-400">
            Case studies showcasing impactful design solutions
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={project.id}
              project={project}
              index={index}
              onClick={() => setSelectedProject(project)}
            />
          ))}
        </div>
      </div>

      {/* Case Study Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-50 overflow-y-auto"
            onClick={() => setSelectedProject(null)}
          >
            <div className="min-h-screen py-12 px-6">
              <div className="max-w-5xl mx-auto">
                <motion.button
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="fixed top-6 right-6 p-3 bg-gray-900/90 backdrop-blur-sm hover:bg-gray-800 rounded-full transition-colors shadow-lg"
                  onClick={() => setSelectedProject(null)}
                >
                  <X className="w-6 h-6" />
                </motion.button>

                <CaseStudy project={selectedProject} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}