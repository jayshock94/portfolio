import { motion } from 'motion/react';
import { Zap, ArrowDown } from 'lucide-react';
import { useState, useEffect } from 'react';

export function Hero() {
  const [introComplete, setIntroComplete] = useState(false);

  useEffect(() => {
    // Mark intro as complete after 3 seconds
    const timer = setTimeout(() => {
      setIntroComplete(true);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const scrollToWork = () => {
    const element = document.getElementById('work');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Electric background effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black">
        {/* Intro electric bolts - dramatic */}
        {!introComplete && (
          <div className="absolute inset-0">
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={`intro-${i}`}
                className="absolute bg-blue-500 rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  width: `${Math.random() * 3 + 1}px`,
                  height: `${Math.random() * 150 + 100}px`,
                  rotate: `${Math.random() * 360}deg`,
                }}
                initial={{ opacity: 0, scaleY: 0 }}
                animate={{
                  opacity: [0, 0.8, 0],
                  scaleY: [0, 1, 0],
                }}
                transition={{
                  duration: 0.6,
                  delay: Math.random() * 2,
                  ease: "easeOut"
                }}
              />
            ))}
            {/* Electric glow pulses */}
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={`glow-${i}`}
                className="absolute rounded-full bg-blue-600/30 blur-3xl"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  width: `${Math.random() * 200 + 150}px`,
                  height: `${Math.random() * 200 + 150}px`,
                }}
                initial={{ opacity: 0, scale: 0 }}
                animate={{
                  opacity: [0, 0.6, 0],
                  scale: [0, 1.5, 0],
                }}
                transition={{
                  duration: 1.5,
                  delay: Math.random() * 1.5,
                  ease: "easeOut"
                }}
              />
            ))}
          </div>
        )}
        
        {/* Subtle ambient effect after intro */}
        <motion.div
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: introComplete ? 1 : 0 }}
          transition={{ duration: 1 }}
        >
          {/* Gentle moving gradients */}
          <motion.div
            className="absolute w-96 h-96 rounded-full bg-blue-600/5 blur-3xl"
            style={{ left: '10%', top: '20%' }}
            animate={{
              x: [0, 30, 0],
              y: [0, -20, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.div
            className="absolute w-96 h-96 rounded-full bg-blue-500/5 blur-3xl"
            style={{ right: '10%', bottom: '20%' }}
            animate={{
              x: [0, -30, 0],
              y: [0, 20, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          {/* Occasional subtle spark */}
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={`ambient-${i}`}
              className="absolute w-px h-20 bg-blue-500/20 rounded-full"
              style={{
                left: `${20 + i * 30}%`,
                top: `${30 + i * 20}%`,
              }}
              animate={{
                opacity: [0, 0.3, 0],
                scaleY: [0, 1, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 3 + 2,
                repeatDelay: 8,
              }}
            />
          ))}
        </motion.div>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex items-center justify-center gap-3 mb-6"
        >
          <motion.div
            animate={introComplete ? {} : { rotate: [0, 15, -15, 0] }}
            transition={{ duration: 0.6, delay: 1 }}
          >
            <Zap className="w-8 h-8 text-blue-500" fill="currentColor" />
          </motion.div>
          <span className="text-gray-400 tracking-widest uppercase">UX/UI Designer</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="mb-6 font-black"
        >
          <span className="block text-7xl md:text-9xl tracking-tight text-white" style={{
            textShadow: `
              2px 2px 0 rgba(100, 100, 120, 0.8),
              4px 4px 0 rgba(80, 80, 100, 0.7),
              6px 6px 0 rgba(60, 60, 80, 0.6),
              8px 8px 0 rgba(40, 40, 60, 0.5),
              10px 10px 20px rgba(0, 0, 0, 0.5)
            `
          }}>
            JAY
          </span>
          <span className="block text-7xl md:text-9xl tracking-tight relative inline-flex items-center justify-center" style={{ letterSpacing: '0.05em' }}>
            <span className="text-blue-300" style={{
              textShadow: `
                2px 2px 0 rgba(59, 130, 246, 0.8),
                4px 4px 0 rgba(37, 99, 235, 0.7),
                6px 6px 0 rgba(29, 78, 216, 0.6),
                8px 8px 0 rgba(30, 64, 175, 0.5),
                10px 10px 20px rgba(59, 130, 246, 0.4)
              `
            }}>S</span>
            <span className="text-blue-300" style={{
              textShadow: `
                2px 2px 0 rgba(59, 130, 246, 0.8),
                4px 4px 0 rgba(37, 99, 235, 0.7),
                6px 6px 0 rgba(29, 78, 216, 0.6),
                8px 8px 0 rgba(30, 64, 175, 0.5),
                10px 10px 20px rgba(59, 130, 246, 0.4)
              `
            }}>H</span>
            
            {/* 3D Electric Orb for O */}
            <span className="inline-flex items-center justify-center relative mx-2" style={{ 
              width: '0.85em', 
              height: '0.85em',
              transform: 'translateY(-0.05em)',
              userSelect: 'none',
              pointerEvents: 'none'
            }}>
              {/* Outer glow with subtle pulse */}
              <motion.span
                className="absolute inset-0 rounded-full"
                style={{
                  background: 'radial-gradient(circle at 30% 30%, rgba(96, 165, 250, 0.4), rgba(59, 130, 246, 0.2))',
                  filter: 'blur(20px)',
                  userSelect: 'none',
                }}
                animate={
                  introComplete
                    ? {
                        opacity: [0.4, 0.6, 0.4],
                        scale: [1, 1.1, 1],
                      }
                    : {}
                }
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              
              {/* Single rotating energy ring */}
              {introComplete && (
                <motion.span
                  className="absolute rounded-full border border-blue-400/30"
                  style={{
                    width: '130%',
                    height: '130%',
                  }}
                  animate={{
                    rotate: 360,
                    opacity: [0.3, 0.5, 0.3],
                  }}
                  transition={{
                    rotate: { duration: 8, repeat: Infinity, ease: "linear" },
                    opacity: { duration: 2, repeat: Infinity, ease: "easeInOut" }
                  }}
                />
              )}
              
              {/* Occasional subtle spark */}
              {introComplete && [0, 1].map((i) => {
                const angle = (i * 180) * (Math.PI / 180);
                return (
                  <motion.span
                    key={`spark-${i}`}
                    className="absolute w-1 h-1 bg-blue-300 rounded-full"
                    style={{
                      left: '50%',
                      top: '50%',
                      filter: 'blur(1px)',
                    }}
                    animate={{
                      opacity: [0, 0.6, 0],
                      x: [0, Math.cos(angle) * 35, 0],
                      y: [0, Math.sin(angle) * 35, 0],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      delay: i * 3,
                      repeatDelay: 4,
                      ease: "easeOut",
                    }}
                  />
                );
              })}
              
              {/* Main orb */}
              <span 
                className="relative rounded-full flex items-center justify-center"
                style={{
                  width: '100%',
                  height: '100%',
                  background: 'linear-gradient(135deg, #93c5fd 0%, #3b82f6 50%, #1d4ed8 100%)',
                  boxShadow: `
                    inset -8px -8px 20px rgba(29, 78, 216, 0.8),
                    inset 8px 8px 20px rgba(147, 197, 253, 0.3),
                    0 8px 16px rgba(0, 0, 0, 0.4),
                    0 0 40px rgba(59, 130, 246, 0.5)
                  `,
                }}
              >
                {/* Highlight */}
                <span 
                  className="absolute rounded-full"
                  style={{
                    top: '15%',
                    left: '20%',
                    width: '35%',
                    height: '35%',
                    background: 'radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.6), transparent)',
                    filter: 'blur(4px)',
                  }}
                />
                
                {/* Lightning bolt */}
                <motion.span 
                  className="relative z-10 text-white"
                  style={{ 
                    fontSize: '0.5em',
                    filter: 'drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3))'
                  }}
                  animate={
                    introComplete
                      ? {}
                      : {
                          scale: [1, 1.2, 1],
                          rotate: [0, -10, 10, 0],
                        }
                  }
                  transition={{
                    duration: 0.5,
                    delay: 1.5,
                  }}
                >
                  ⚡
                </motion.span>
              </span>
              
              {/* Electric particles during intro */}
              {!introComplete && [0, 1, 2, 3].map((i) => (
                <motion.span
                  key={i}
                  className="absolute w-2 h-2 bg-blue-400 rounded-full"
                  style={{
                    left: '50%',
                    top: '50%',
                  }}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{
                    opacity: [0, 1, 0],
                    scale: [0, 1, 0],
                    x: Math.cos((i * Math.PI) / 2) * 80,
                    y: Math.sin((i * Math.PI) / 2) * 80,
                  }}
                  transition={{
                    duration: 1.2,
                    delay: 1.5 + i * 0.1,
                  }}
                />
              ))}
            </span>
            
            <span className="text-blue-300" style={{
              textShadow: `
                2px 2px 0 rgba(59, 130, 246, 0.8),
                4px 4px 0 rgba(37, 99, 235, 0.7),
                6px 6px 0 rgba(29, 78, 216, 0.6),
                8px 8px 0 rgba(30, 64, 175, 0.5),
                10px 10px 20px rgba(59, 130, 246, 0.4)
              `
            }}>C</span>
            <span className="text-blue-300" style={{
              textShadow: `
                2px 2px 0 rgba(59, 130, 246, 0.8),
                4px 4px 0 rgba(37, 99, 235, 0.7),
                6px 6px 0 rgba(29, 78, 216, 0.6),
                8px 8px 0 rgba(30, 64, 175, 0.5),
                10px 10px 20px rgba(59, 130, 246, 0.4)
              `
            }}>K</span>
            
            {!introComplete && (
              <motion.span
                className="absolute -right-4 -top-4 text-blue-500 text-6xl"
                initial={{ opacity: 0, scale: 0 }}
                animate={{
                  opacity: [0, 1, 1, 0],
                  scale: [0, 1.5, 1.5, 0],
                }}
                transition={{
                  duration: 2,
                  times: [0, 0.2, 0.8, 1],
                  delay: 1.2,
                }}
              >
                ⚡
              </motion.span>
            )}
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="text-xl text-gray-400 max-w-2xl mx-auto mb-12"
        >
          Creating electrifying digital experiences that spark engagement and drive results. 
          Specializing in user-centered design that makes an impact.
        </motion.p>

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          onClick={scrollToWork}
          className="group inline-flex items-center gap-2 px-8 py-4 bg-blue-500 text-white hover:bg-blue-400 transition-all duration-300 relative overflow-hidden rounded-full shadow-lg shadow-blue-500/30"
        >
          <span className="relative z-10 tracking-wide">View My Work</span>
          <ArrowDown className="w-5 h-5 relative z-10 group-hover:translate-y-1 transition-transform" />
          <motion.div
            className="absolute inset-0 bg-blue-300"
            initial={{ x: '-100%' }}
            whileHover={{ x: 0 }}
            transition={{ duration: 0.3 }}
          />
        </motion.button>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ 
          opacity: { delay: 1.5, duration: 0.5 },
          y: { duration: 2, repeat: Infinity, delay: 2 }
        }}
      >
        <div className="w-6 h-10 border-2 border-gray-600 rounded-full flex items-start justify-center p-2">
          <motion.div
            className="w-1.5 h-1.5 bg-blue-500 rounded-full"
            animate={{ y: [0, 16, 0] }}
            transition={{ duration: 2, repeat: Infinity, delay: 2 }}
          />
        </div>
      </motion.div>
    </section>
  );
}