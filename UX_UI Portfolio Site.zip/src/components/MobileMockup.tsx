import { HomeScreen } from '../imports/Home';

export function MobileMockup() {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-900 to-black p-8">
      {/* Phone frame */}
      <div className="relative">
        {/* Phone device frame */}
        <div className="relative bg-black rounded-[3rem] p-3 shadow-2xl">
          {/* Screen */}
          <div className="relative bg-white rounded-[2.5rem] overflow-hidden w-[402px] h-[869px]">
            <HomeScreen />
          </div>
        </div>
        
        {/* Phone frame highlights */}
        <div className="absolute inset-0 rounded-[3rem] border-2 border-gray-800 pointer-events-none" />
      </div>
    </div>
  );
}
