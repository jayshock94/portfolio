import lendingImage from 'figma:asset/1a47aa4e5aad4c8f66017dd4278f992e074f694f.png';

export function LendingEngineMockup() {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 p-8">
      {/* Glow effects */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-500/30 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl" />
      
      {/* Browser mockup */}
      <div className="relative w-full max-w-5xl" style={{ transform: 'scale(0.85)' }}>
        {/* Shadow */}
        <div className="absolute inset-0 bg-black/40 blur-2xl transform translate-y-8" />
        
        {/* Browser window */}
        <div className="relative bg-gray-900 rounded-t-xl shadow-2xl">
          {/* Browser chrome */}
          <div className="flex items-center gap-2 px-4 py-3 bg-gray-800 rounded-t-xl border-b border-gray-700">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
            </div>
            <div className="flex-1 mx-4 bg-gray-700 rounded px-3 py-1 text-xs text-gray-400">
              lendingengine.com/customers/dashboard
            </div>
          </div>
          
          {/* Screen content */}
          <div className="relative bg-white overflow-hidden">
            <img 
              src={lendingImage} 
              alt="Lending Engine Dashboard"
              className="w-full h-auto"
            />
          </div>
        </div>
        
        {/* Reflection */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-transparent rounded-t-xl pointer-events-none" />
      </div>
    </div>
  );
}
