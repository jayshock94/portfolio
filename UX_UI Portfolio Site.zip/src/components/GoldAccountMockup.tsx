import Home1 from '../imports/Home';

export function GoldAccountMockup() {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-black p-8">
      {/* Phone mockup container */}
      <div className="relative" style={{ transform: 'scale(0.85)' }}>
        {/* Shadow */}
        <div className="absolute inset-0 bg-blue-500/10 blur-3xl transform translate-y-12 scale-110" />
        
        {/* Phone frame - iPhone style */}
        <div className="relative bg-[#1a1a1a] rounded-[60px] p-[14px] shadow-2xl" style={{ width: '430px', height: '900px' }}>
          {/* Inner bezel */}
          <div className="absolute inset-[14px] rounded-[46px] border border-gray-800" />
          
          {/* Screen */}
          <div className="relative bg-white rounded-[46px] overflow-hidden w-full h-full">
            {/* Render the actual Figma screen */}
            <div style={{ width: '402px', height: '874px' }}>
              <Home1 />
            </div>
          </div>
          
          {/* Side buttons */}
          <div className="absolute right-[-3px] top-[140px] w-[3px] h-[60px] bg-gray-700 rounded-l-sm" />
          <div className="absolute right-[-3px] top-[220px] w-[3px] h-[60px] bg-gray-700 rounded-l-sm" />
          <div className="absolute right-[-3px] top-[290px] w-[3px] h-[60px] bg-gray-700 rounded-l-sm" />
          <div className="absolute left-[-3px] top-[200px] w-[3px] h-[90px] bg-gray-700 rounded-r-sm" />
        </div>
        
        {/* Reflections/highlights */}
        <div className="absolute inset-0 rounded-[60px] bg-gradient-to-br from-white/5 via-transparent to-transparent pointer-events-none" />
      </div>
    </div>
  );
}
