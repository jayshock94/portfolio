import { motion } from 'motion/react';
import { Mail, Linkedin, Twitter, Github, Send } from 'lucide-react';

const socialLinks = [
  { icon: Linkedin, label: 'LinkedIn', href: '#' },
  { icon: Twitter, label: 'Twitter', href: '#' },
  { icon: Github, label: 'GitHub', href: '#' },
  { icon: Mail, label: 'Email', href: 'mailto:jay@shock.design' },
];

export function Contact() {
  return (
    <section id="contact" className="py-32 px-6 bg-gray-900 relative overflow-hidden">
      {/* Subtle electric effect background */}
      <div className="absolute inset-0 opacity-5">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-px bg-blue-500 rounded-full"
            style={{
              left: `${20 + i * 20}%`,
              top: `${Math.random() * 100}%`,
              height: `${Math.random() * 150 + 100}px`,
            }}
            animate={{
              opacity: [0, 0.5, 0],
              scaleY: [0, 1, 0],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              delay: i * 2,
              repeatDelay: 10,
            }}
          />
        ))}
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl mb-6">
            Let's Create Something <span className="text-blue-500">Electric</span>
          </h2>
          <p className="text-xl text-gray-400">
            Have a project in mind? Let's discuss how we can work together to create 
            experiences that shock and delight your users.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-16"
        >
          <a
            href="mailto:jay@shock.design"
            className="group inline-flex items-center gap-3 px-10 py-5 bg-blue-500 text-white hover:bg-blue-600 transition-all duration-300 text-xl relative overflow-hidden rounded-full shadow-lg shadow-blue-500/30"
          >
            <span className="relative z-10">Get in Touch</span>
            <Send className="w-6 h-6 relative z-10 group-hover:translate-x-1 transition-transform" />
            <motion.div
              className="absolute inset-0 bg-blue-400"
              initial={{ x: '-100%' }}
              whileHover={{ x: 0 }}
              transition={{ duration: 0.3 }}
            />
          </a>
        </motion.div>

        {/* Social Links */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex justify-center gap-6 mb-16"
        >
          {socialLinks.map((social, index) => (
            <motion.a
              key={social.label}
              href={social.href}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-4 bg-gray-900/50 backdrop-blur-sm rounded-2xl hover:bg-blue-500/10 hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300 group"
              aria-label={social.label}
            >
              <social.icon className="w-6 h-6 text-gray-400 group-hover:text-blue-400 transition-colors" />
            </motion.a>
          ))}
        </motion.div>

        {/* Footer */}
        <div className="text-center text-gray-500 border-t border-gray-800 pt-8">
          <p className="mb-2">© 2025 Jay Shock. All rights reserved.</p>
          <p className="text-sm">Designed & built with ⚡ by Jay Shock</p>
        </div>
      </div>
    </section>
  );
}