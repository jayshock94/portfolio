export function GoldAccountThumbnail() {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200 p-12">
      {/* Phone mockup */}
      <div className="relative" style={{ transform: 'scale(0.8)' }}>
        {/* Phone frame shadow */}
        <div className="absolute inset-0 bg-black/20 blur-3xl transform translate-y-8" />
        
        {/* Phone device */}
        <div className="relative bg-black rounded-[50px] p-4 shadow-2xl" style={{ width: '320px', height: '650px' }}>
          {/* Screen */}
          <div className="relative bg-[#fff8f7] rounded-[42px] overflow-hidden w-full h-full">
            {/* Status bar */}
            <div className="flex items-center justify-between px-6 pt-4 pb-2">
              <span className="text-sm font-semibold">9:41</span>
              <div className="flex gap-1 items-center">
                <div className="w-4 h-3 border border-black/30 rounded-sm" />
              </div>
            </div>
            
            {/* Logo */}
            <div className="px-6 py-3">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold">
                  <span className="text-red-800">Lend</span>
                  <span className="text-gray-700">mark</span>
                </div>
                <svg className="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
              </div>
            </div>
            
            {/* Content */}
            <div className="px-6 space-y-4">
              {/* Greeting */}
              <h1 className="text-2xl font-serif text-gray-900 mb-3">Good afternoon, John</h1>
              
              {/* Promotional card */}
              <div className="bg-gradient-to-br from-red-800 to-red-900 rounded-xl p-4 shadow-lg">
                <div className="bg-red-50/20 rounded-full text-[8px] text-red-100 px-3 py-1 inline-block mb-2">
                  Start the Year Strong. Finance Your Dreams.
                </div>
                <div className="text-red-100 text-xs font-bold mb-1">Drive Now, Pay Less.</div>
                <div className="text-white">
                  <span className="text-3xl font-bold">3.0%</span>
                  <span className="text-xs ml-1">APR</span>
                </div>
                <div className="text-red-100 text-[8px] mt-2">Now until Feb 1</div>
              </div>
              
              {/* Loan card */}
              <div className="bg-red-50 rounded-xl p-3 shadow-sm flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-900">Apply for a loan</p>
                  <p className="text-xs text-gray-600">Apply now</p>
                </div>
                <div className="w-12 h-12 bg-white rounded-lg" />
              </div>
              
              {/* Accounts section */}
              <div className="pt-2">
                <h2 className="text-xl font-serif text-gray-900 mb-3">Accounts</h2>
                
                {/* Account card */}
                <div className="bg-white rounded-xl p-3 shadow-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <svg className="w-4 h-4 text-blue-700" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
                    </svg>
                    <p className="text-xs text-gray-600">2021 Jeep Rubicon 1234</p>
                  </div>
                  <div className="flex items-baseline gap-2 pl-6">
                    <p className="text-base font-medium text-gray-900">$15,000.35</p>
                    <p className="text-[9px] text-gray-500">Current balance</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
