import { motion } from 'motion/react';
import { CheckCircle, Target, Lightbulb, TrendingUp, Workflow } from 'lucide-react';
import { Project } from './Projects';

interface CaseStudyProps {
  project: Project;
}

export function CaseStudy({ project }: CaseStudyProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      onClick={(e) => e.stopPropagation()}
      className="bg-gray-900/50 backdrop-blur-sm rounded-3xl overflow-hidden"
    >
      {/* Header */}
      <div className="relative h-96 overflow-hidden">
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-12">
          <div className="px-4 py-2 bg-blue-500 text-white rounded-full text-sm tracking-wider inline-block mb-4 shadow-lg">
            {project.category}
          </div>
          <h1 className="text-5xl md:text-6xl mb-4">{project.title}</h1>
          <p className="text-xl text-gray-300">{project.description}</p>
        </div>
      </div>

      <div className="p-12">
        {/* Challenge */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-blue-500/20 rounded-2xl">
              <Target className="w-8 h-8 text-blue-400" />
            </div>
            <h2 className="text-3xl">The Challenge</h2>
          </div>
          <p className="text-xl text-gray-300 leading-relaxed">
            {project.caseStudy.challenge}
          </p>
        </section>

        {/* Solution */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-blue-500/20 rounded-2xl">
              <Lightbulb className="w-8 h-8 text-blue-400" />
            </div>
            <h2 className="text-3xl">The Solution</h2>
          </div>
          <p className="text-xl text-gray-300 leading-relaxed">
            {project.caseStudy.solution}
          </p>
        </section>

        {/* Impact */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-blue-500/20 rounded-2xl">
              <TrendingUp className="w-8 h-8 text-blue-400" />
            </div>
            <h2 className="text-3xl">Impact & Results</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {project.caseStudy.impact.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-start gap-3 p-6 bg-blue-500/10 rounded-2xl border border-blue-500/20"
              >
                <CheckCircle className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
                <span className="text-lg text-gray-300">{item}</span>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Process */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 bg-blue-500/20 rounded-2xl">
              <Workflow className="w-8 h-8 text-blue-400" />
            </div>
            <h2 className="text-3xl">Design Process</h2>
          </div>
          <div className="space-y-8">
            {project.caseStudy.process.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-8 border-l-2 border-gray-800"
              >
                <div className="absolute -left-4 top-0 w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-500/30">
                  {index + 1}
                </div>
                <h3 className="text-2xl mb-3">{step.title}</h3>
                <p className="text-lg text-gray-400 leading-relaxed">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Additional Images */}
        {project.caseStudy.images.length > 0 && (
          <section>
            <h2 className="text-3xl mb-8">Project Showcase</h2>
            <div className="grid grid-cols-1 gap-6">
              {project.caseStudy.images.map((image, index) => (
                <motion.img
                  key={index}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.2 }}
                  src={image}
                  alt={`${project.title} showcase ${index + 1}`}
                  className="w-full h-auto rounded-2xl"
                />
              ))}
            </div>
          </section>
        )}
      </div>
    </motion.div>
  );
}