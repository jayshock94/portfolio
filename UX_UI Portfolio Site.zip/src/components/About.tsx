import { motion } from 'motion/react';
import { Zap, Users, Sparkles, Building2 } from 'lucide-react';

const stats = [
  { icon: Zap, label: 'Years Experience', value: '5+' },
  { icon: Users, label: 'Projects Delivered', value: '50+' },
  { icon: Sparkles, label: 'Happy Clients', value: '35+' },
  { icon: Building2, label: 'Fortune 500 Clients', value: '2' },
];

const skills = [
  'User Research',
  'Information Architecture',
  'Wireframing & Prototyping',
  'Visual Design',
  'Design Systems',
  'Usability Testing',
  'Mobile Design',
  'Interaction Design',
  'Figma',
  'Adobe Creative Suite',
  'Motion Design',
  'Accessibility'
];

export function About() {
  return (
    <section id="about" className="py-32 px-6 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-5xl md:text-6xl mb-6">
            About <span className="text-blue-500">Me</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <p className="text-xl text-gray-300 leading-relaxed mb-6">
              I'm a UX/UI designer who believes great design should do more than look good—it should 
              create moments that spark joy, solve real problems, and drive measurable results.
            </p>
            <p className="text-xl text-gray-300 leading-relaxed mb-6">
              With over 5 years of experience, I've worked with startups and Fortune 500 
              companies like <span className="text-purple-400">T-Mobile</span> and <span className="text-purple-400">DishNetwork</span> to craft digital experiences that users love and businesses value. My approach 
              combines user research, strategic thinking, and meticulous craft.
            </p>
            <p className="text-xl text-gray-300 leading-relaxed">
              When I'm not designing, you'll find me exploring the outdoors, mentoring aspiring designers, 
              or staying current with the latest design tools and technologies.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <h3 className="text-2xl mb-6 text-blue-400">Core Skills</h3>
            <div className="flex flex-wrap gap-3">
              {skills.map((skill, index) => (
                <motion.span
                  key={skill}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="px-4 py-2 bg-white/5 rounded-full hover:bg-blue-500/10 hover:border-blue-500/50 border border-gray-800 transition-colors"
                >
                  {skill}
                </motion.span>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center p-8 bg-gray-900/50 backdrop-blur-sm rounded-3xl hover:shadow-xl hover:shadow-purple-500/10 transition-all duration-300 group"
            >
              <div className="p-3 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                <stat.icon className="w-8 h-8 text-blue-400 group-hover:text-purple-400 transition-colors" />
              </div>
              <div className="text-3xl mb-2 group-hover:text-purple-400 transition-colors">
                {stat.value}
              </div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}