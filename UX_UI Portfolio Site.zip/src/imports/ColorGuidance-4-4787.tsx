import svgPaths from "./svg-2lgpbq4kz8";

function Logo() {
  return (
    <div className="absolute left-0 size-[40px] top-0" data-name="Logo">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g clipPath="url(#clip0_4_4791)" id="Logo">
          <path d={svgPaths.p1a7cad80} id="Vector" stroke="var(--stroke-0, black)" />
          <path d="M33.5 6.5V33.5H6.5V6.5H33.5Z" id="Vector_2" stroke="var(--stroke-0, black)" />
          <g id="Vector_3">
            <mask fill="white" id="path-3-inside-1_4_4791">
              <path clipRule="evenodd" d={svgPaths.p1d83500} fillRule="evenodd" />
            </mask>
            <path d={svgPaths.p1c65580} fill="var(--stroke-0, black)" mask="url(#path-3-inside-1_4_4791)" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_4_4791">
            <rect fill="white" height="40" width="40" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Logo1() {
  return (
    <div className="h-[40px] relative shrink-0 w-full" data-name="Logo">
      <Logo />
    </div>
  );
}

function Title() {
  return (
    <div className="content-stretch flex flex-col font-['Roboto:Regular',sans-serif] font-normal gap-[24px] items-start relative shrink-0 w-full" data-name="Title">
      <p className="leading-[normal] relative shrink-0 text-[80px] text-black text-center text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Color Guidance
      </p>
      <p className="leading-[32px] relative shrink-0 text-[#33618d] text-[24px] text-center text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        <span className="text-black">See design guideline for</span>{" "}
        <a className="[text-decoration-skip-ink:none] [text-underline-position:from-font] cursor-pointer decoration-solid underline" href="https://m3.material.io/styles/color/overview">
          <span className="[text-decoration-skip-ink:none] [text-underline-position:from-font] decoration-solid leading-[32px]" href="https://m3.material.io/styles/color/overview">
            color
          </span>
        </a>{" "}
        <span className="text-black">and</span>{" "}
        <a className="[text-decoration-skip-ink:none] [text-underline-position:from-font] cursor-pointer decoration-solid underline" href="https://m3.material.io/foundations/interaction-states">
          <span className="[text-decoration-skip-ink:none] [text-underline-position:from-font] decoration-solid leading-[32px]" href="https://m3.material.io/foundations/interaction-states">
            interaction states
          </span>
        </a>
      </p>
      <p className="leading-[24px] min-w-full relative shrink-0 text-[18px] text-black w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Use color to create meaningful experiences while also expressing hierarchy, state, and brand identity
      </p>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#e0e2e8] relative shrink-0 w-full" data-name="Header">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="box-border content-stretch flex flex-col gap-[60px] items-start pb-[70px] pt-[52px] px-[52px] relative w-full">
          <Logo1 />
          <Title />
        </div>
      </div>
    </div>
  );
}

function TonalPalettes() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative" data-name="Tonal palettes">
      <p className="[grid-area:1_/_1] font-['Roboto:Regular',sans-serif] font-normal leading-[24px] ml-[140px] mt-0 relative text-[18px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Tonal Palettes
      </p>
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-0 mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Primary
      </p>
      <div className="[grid-area:1_/_1] bg-black h-[108px] ml-[140px] mt-[80px] w-[61px]" data-name="primary0" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[165px] mt-[90px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0
      </p>
      <div className="[grid-area:1_/_1] bg-[#001d35] h-[108px] ml-[201px] mt-[80px] w-[61px]" data-name="primary10" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[222.5px] mt-[90px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        10
      </p>
      <div className="[grid-area:1_/_1] bg-[#003256] h-[108px] ml-[262px] mt-[80px] w-[61px]" data-name="primary20" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[282.5px] mt-[90px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        20
      </p>
      <div className="[grid-area:1_/_1] bg-[#004a7a] h-[108px] ml-[323px] mt-[80px] w-[61px]" data-name="primary30" />
      <div className="[grid-area:1_/_1] bg-[#0062a0] h-[108px] ml-[384px] mt-[80px] w-[61px]" data-name="primary40" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[404px] mt-[90px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        40
      </p>
      <div className="[grid-area:1_/_1] bg-[#007bc8] h-[108px] ml-[445px] mt-[80px] w-[61px]" data-name="primary50" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[465px] mt-[90px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        50
      </p>
      <div className="[grid-area:1_/_1] bg-[#0096f1] h-[108px] ml-[506px] mt-[80px] w-[61px]" data-name="primary60" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[526px] mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        60
      </p>
      <div className="[grid-area:1_/_1] bg-[#5cb0ff] h-[108px] ml-[567px] mt-[80px] w-[61px]" data-name="primary70" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[587.5px] mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        70
      </p>
      <div className="[grid-area:1_/_1] bg-[#9bcaff] h-[108px] ml-[628px] mt-[80px] w-[61px]" data-name="primary80" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[648.5px] mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        80
      </p>
      <div className="[grid-area:1_/_1] bg-[#d0e4ff] h-[108px] ml-[689px] mt-[80px] w-[61px]" data-name="primary90" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[709px] mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        90
      </p>
      <div className="[grid-area:1_/_1] bg-[#e9f1ff] h-[108px] ml-[750px] mt-[80px] w-[61px]" data-name="primary95" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[771px] mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        95
      </p>
      <div className="[grid-area:1_/_1] bg-[#fdfcff] h-[108px] ml-[811px] mt-[80px] w-[61px]" data-name="primary99" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[832px] mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        99
      </p>
      <div className="[grid-area:1_/_1] bg-white h-[108px] ml-[872px] mt-[80px] w-[61px]" data-name="primary100" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[888px] mt-[90px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        100
      </p>
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-0 mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Secondary
      </p>
      <div className="[grid-area:1_/_1] bg-black h-[108px] ml-[140px] mt-[208px] w-[61px]" data-name="secondary0" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[165px] mt-[218px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0
      </p>
      <div className="[grid-area:1_/_1] bg-[#081d2f] h-[108px] ml-[201px] mt-[208px] w-[61px]" data-name="secondary10" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[222.5px] mt-[218px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        10
      </p>
      <div className="[grid-area:1_/_1] bg-[#1f3245] h-[108px] ml-[262px] mt-[208px] w-[61px]" data-name="secondary20" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[282.5px] mt-[218px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        20
      </p>
      <div className="[grid-area:1_/_1] bg-[#36485d] h-[108px] ml-[323px] mt-[208px] w-[61px]" data-name="secondary30" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[343.5px] mt-[218px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        30
      </p>
      <div className="[grid-area:1_/_1] bg-[#4e6075] h-[108px] ml-[384px] mt-[208px] w-[61px]" data-name="secondary40" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[404px] mt-[218px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        40
      </p>
      <div className="[grid-area:1_/_1] bg-[#66798f] h-[108px] ml-[445px] mt-[208px] w-[61px]" data-name="secondary50" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[465px] mt-[218px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        50
      </p>
      <div className="[grid-area:1_/_1] bg-[#8092a9] h-[108px] ml-[506px] mt-[208px] w-[61px]" data-name="secondary60" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[526px] mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        60
      </p>
      <div className="[grid-area:1_/_1] bg-[#9aadc5] h-[108px] ml-[567px] mt-[208px] w-[61px]" data-name="secondary70" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[587.5px] mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        70
      </p>
      <div className="[grid-area:1_/_1] bg-[#b5c8e1] h-[108px] ml-[628px] mt-[208px] w-[61px]" data-name="secondary80" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[648.5px] mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        80
      </p>
      <div className="[grid-area:1_/_1] bg-[#d1e4fe] h-[108px] ml-[689px] mt-[208px] w-[61px]" data-name="secondary90" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[709px] mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        90
      </p>
      <div className="[grid-area:1_/_1] bg-[#e9f1ff] h-[108px] ml-[750px] mt-[208px] w-[61px]" data-name="secondary95" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[771px] mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        95
      </p>
      <div className="[grid-area:1_/_1] bg-[#fdfcff] h-[108px] ml-[811px] mt-[208px] w-[61px]" data-name="secondary99" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[832px] mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        99
      </p>
      <div className="[grid-area:1_/_1] bg-white h-[108px] ml-[872px] mt-[208px] w-[61px]" data-name="secondary100" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[888px] mt-[218px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        100
      </p>
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-0 mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Tertiary
      </p>
      <div className="[grid-area:1_/_1] bg-black h-[108px] ml-[140px] mt-[336px] w-[61px]" data-name="tertiary0" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[165px] mt-[346px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0
      </p>
      <div className="[grid-area:1_/_1] bg-[#281900] h-[108px] ml-[201px] mt-[336px] w-[61px]" data-name="tertiary10" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[222.5px] mt-[346px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        10
      </p>
      <div className="[grid-area:1_/_1] bg-[#432c00] h-[108px] ml-[262px] mt-[336px] w-[61px]" data-name="tertiary20" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[282.5px] mt-[346px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        20
      </p>
      <div className="[grid-area:1_/_1] bg-[#604100] h-[108px] ml-[323px] mt-[336px] w-[61px]" data-name="tertiary30" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[343.5px] mt-[346px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        30
      </p>
      <div className="[grid-area:1_/_1] bg-[#7e5700] h-[108px] ml-[384px] mt-[336px] w-[61px]" data-name="tertiary40" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[404px] mt-[346px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        40
      </p>
      <div className="[grid-area:1_/_1] bg-[#9e6e00] h-[108px] ml-[445px] mt-[336px] w-[61px]" data-name="tertiary50" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[465px] mt-[346px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        50
      </p>
      <div className="[grid-area:1_/_1] bg-[#bf8600] h-[108px] ml-[506px] mt-[336px] w-[61px]" data-name="tertiary60" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[526px] mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        60
      </p>
      <div className="[grid-area:1_/_1] bg-[#e29e00] h-[108px] ml-[567px] mt-[336px] w-[61px]" data-name="tertiary70" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[587.5px] mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        70
      </p>
      <div className="[grid-area:1_/_1] bg-[#ffba37] h-[108px] ml-[628px] mt-[336px] w-[61px]" data-name="tertiary80" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[648.5px] mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        80
      </p>
      <div className="[grid-area:1_/_1] bg-[#ffdeac] h-[108px] ml-[689px] mt-[336px] w-[61px]" data-name="tertiary90" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[709px] mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        90
      </p>
      <div className="[grid-area:1_/_1] bg-[#ffeed9] h-[108px] ml-[750px] mt-[336px] w-[61px]" data-name="tertiary95" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[771px] mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        95
      </p>
      <div className="[grid-area:1_/_1] bg-[#fffbff] h-[108px] ml-[811px] mt-[336px] w-[61px]" data-name="tertiary99" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[832px] mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        99
      </p>
      <div className="[grid-area:1_/_1] bg-white h-[108px] ml-[872px] mt-[336px] w-[61px]" data-name="tertiary100" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[888px] mt-[346px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        100
      </p>
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-0 mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Error
      </p>
      <div className="[grid-area:1_/_1] bg-black h-[108px] ml-[140px] mt-[464px] w-[61px]" data-name="error0" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[165px] mt-[474px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0
      </p>
      <div className="[grid-area:1_/_1] bg-[#410002] h-[108px] ml-[201px] mt-[464px] w-[61px]" data-name="error10" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[222.5px] mt-[474px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        10
      </p>
      <div className="[grid-area:1_/_1] bg-[#690005] h-[108px] ml-[262px] mt-[464px] w-[61px]" data-name="error20" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[282.5px] mt-[474px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        20
      </p>
      <div className="[grid-area:1_/_1] bg-[#93000a] h-[108px] ml-[323px] mt-[464px] w-[61px]" data-name="error30" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[343.5px] mt-[474px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        30
      </p>
      <div className="[grid-area:1_/_1] bg-[#ba1a1a] h-[108px] ml-[384px] mt-[464px] w-[61px]" data-name="error40" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[404px] mt-[474px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        40
      </p>
      <div className="[grid-area:1_/_1] bg-[#de3730] h-[108px] ml-[445px] mt-[464px] w-[61px]" data-name="error50" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[465px] mt-[474px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        50
      </p>
      <div className="[grid-area:1_/_1] bg-[#ff5449] h-[108px] ml-[506px] mt-[464px] w-[61px]" data-name="error60" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[526px] mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        60
      </p>
      <div className="[grid-area:1_/_1] bg-[#ff897d] h-[108px] ml-[567px] mt-[464px] w-[61px]" data-name="error70" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[587.5px] mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        70
      </p>
      <div className="[grid-area:1_/_1] bg-[#ffb4ab] h-[108px] ml-[628px] mt-[464px] w-[61px]" data-name="error80" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[648.5px] mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        80
      </p>
      <div className="[grid-area:1_/_1] bg-[#ffdad6] h-[108px] ml-[689px] mt-[464px] w-[61px]" data-name="error90" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[709px] mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        90
      </p>
      <div className="[grid-area:1_/_1] bg-[#ffedea] h-[108px] ml-[750px] mt-[464px] w-[61px]" data-name="error95" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[771px] mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        95
      </p>
      <div className="[grid-area:1_/_1] bg-[#fffbff] h-[108px] ml-[811px] mt-[464px] w-[61px]" data-name="error99" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[832px] mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        99
      </p>
      <div className="[grid-area:1_/_1] bg-white h-[108px] ml-[872px] mt-[464px] w-[61px]" data-name="error100" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[888px] mt-[474px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        100
      </p>
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-0 mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Neutral
      </p>
      <div className="[grid-area:1_/_1] bg-black h-[108px] ml-[140px] mt-[632px] w-[61px]" data-name="neutral0" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[165px] mt-[642px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0
      </p>
      <div className="[grid-area:1_/_1] bg-[#1a1c1e] h-[108px] ml-[201px] mt-[632px] w-[61px]" data-name="neutral10" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[222.5px] mt-[642px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        10
      </p>
      <div className="[grid-area:1_/_1] bg-[#2f3033] h-[108px] ml-[262px] mt-[632px] w-[61px]" data-name="neutral20" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[282.5px] mt-[642px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        20
      </p>
      <div className="[grid-area:1_/_1] bg-[#45474a] h-[108px] ml-[323px] mt-[632px] w-[61px]" data-name="neutral30" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[343.5px] mt-[642px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        30
      </p>
      <div className="[grid-area:1_/_1] bg-[#5d5e61] h-[108px] ml-[384px] mt-[632px] w-[61px]" data-name="neutral40" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[404px] mt-[642px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        40
      </p>
      <div className="[grid-area:1_/_1] bg-[#76777a] h-[108px] ml-[445px] mt-[632px] w-[61px]" data-name="neutral50" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[465px] mt-[642px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        50
      </p>
      <div className="[grid-area:1_/_1] bg-[#909094] h-[108px] ml-[506px] mt-[632px] w-[61px]" data-name="neutral60" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[526px] mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        60
      </p>
      <div className="[grid-area:1_/_1] bg-[#ababae] h-[108px] ml-[567px] mt-[632px] w-[61px]" data-name="neutral70" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[587.5px] mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        70
      </p>
      <div className="[grid-area:1_/_1] bg-[#c6c6ca] h-[108px] ml-[628px] mt-[632px] w-[61px]" data-name="neutral80" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[648.5px] mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        80
      </p>
      <div className="[grid-area:1_/_1] bg-[#e2e2e6] h-[108px] ml-[689px] mt-[632px] w-[61px]" data-name="neutral90" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[709px] mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        90
      </p>
      <div className="[grid-area:1_/_1] bg-[#f1f0f4] h-[108px] ml-[750px] mt-[632px] w-[61px]" data-name="neutral95" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[771px] mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        95
      </p>
      <div className="[grid-area:1_/_1] bg-[#fdfcff] h-[108px] ml-[811px] mt-[632px] w-[61px]" data-name="neutral99" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[832px] mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        99
      </p>
      <div className="[grid-area:1_/_1] bg-white h-[108px] ml-[872px] mt-[632px] w-[61px]" data-name="neutral100" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[888px] mt-[642px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        100
      </p>
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-0 mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Neutral Variant
      </p>
      <div className="[grid-area:1_/_1] bg-black h-[70px] ml-[140px] mt-[760px] w-[61px]" data-name="neutral-variant0" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[165px] mt-[770px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        0
      </p>
      <div className="[grid-area:1_/_1] bg-[#171c22] h-[70px] ml-[201px] mt-[760px] w-[61px]" data-name="neutral-variant10" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[222.5px] mt-[770px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        10
      </p>
      <div className="[grid-area:1_/_1] bg-[#2c3137] h-[70px] ml-[262px] mt-[760px] w-[61px]" data-name="neutral-variant20" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[282.5px] mt-[770px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        20
      </p>
      <div className="[grid-area:1_/_1] bg-[#42474e] h-[70px] ml-[323px] mt-[760px] w-[61px]" data-name="neutral-variant30" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[343.5px] mt-[770px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        30
      </p>
      <div className="[grid-area:1_/_1] bg-[#5a5f66] h-[70px] ml-[384px] mt-[760px] w-[61px]" data-name="neutral-variant40" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[404px] mt-[770px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        40
      </p>
      <div className="[grid-area:1_/_1] bg-[#73777f] h-[70px] ml-[445px] mt-[760px] w-[61px]" data-name="neutral-variant50" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[465px] mt-[770px] relative text-[16px] text-nowrap text-white tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        50
      </p>
      <div className="[grid-area:1_/_1] bg-[#8c9199] h-[70px] ml-[506px] mt-[760px] w-[61px]" data-name="neutral-variant60" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[526px] mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        60
      </p>
      <div className="[grid-area:1_/_1] bg-[#a7abb3] h-[70px] ml-[567px] mt-[760px] w-[61px]" data-name="neutral-variant70" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[587.5px] mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        70
      </p>
      <div className="[grid-area:1_/_1] bg-[#c2c7cf] h-[70px] ml-[628px] mt-[760px] w-[61px]" data-name="neutral-variant80" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[648.5px] mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        80
      </p>
      <div className="[grid-area:1_/_1] bg-[#dfe3eb] h-[70px] ml-[689px] mt-[760px] w-[61px]" data-name="neutral-variant90" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[709px] mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        90
      </p>
      <div className="[grid-area:1_/_1] bg-[#edf1f9] h-[70px] ml-[750px] mt-[760px] w-[61px]" data-name="neutral-variant95" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[771px] mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        95
      </p>
      <div className="[grid-area:1_/_1] bg-[#fdfcff] h-[70px] ml-[811px] mt-[760px] w-[61px]" data-name="neutral-variant99" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[832px] mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        99
      </p>
      <div className="[grid-area:1_/_1] bg-white h-[70px] ml-[872px] mt-[760px] w-[61px]" data-name="neutral-variant100" />
      <p className="[grid-area:1_/_1] font-['Roboto:Medium',sans-serif] font-medium leading-[24px] ml-[888px] mt-[770px] relative text-[16px] text-black text-nowrap tracking-[0.1px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        100
      </p>
    </div>
  );
}

function LightTheme() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[973px] mt-0 place-items-start relative" data-name="Light theme">
      <p className="[grid-area:1_/_1] font-['Roboto:Regular',sans-serif] font-normal leading-[24px] ml-0 mt-0 relative text-[18px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Light Theme
      </p>
    </div>
  );
}

function DarkTheme() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[1857px] mt-0 place-items-start relative" data-name="Dark theme">
      <p className="[grid-area:1_/_1] font-['Roboto:Regular',sans-serif] font-normal leading-[24px] ml-0 mt-0 relative text-[18px] text-black text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
        Dark Theme
      </p>
    </div>
  );
}

function MaterialTheme() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="material-theme">
      <TonalPalettes />
      <LightTheme />
      <DarkTheme />
    </div>
  );
}

function Swatch() {
  return (
    <div className="basis-0 bg-[#ba1a1a] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[11px] text-white tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Error</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-40</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch1() {
  return (
    <div className="bg-white h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#ba1a1a] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Error</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-100</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch />
      <Swatch1 />
    </div>
  );
}

function Swatch2() {
  return (
    <div className="basis-0 bg-[#ffdad6] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#93000a] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Error Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch3() {
  return (
    <div className="bg-[#93000a] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#ffdad6] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Error Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup1() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch2 />
      <Swatch3 />
    </div>
  );
}

function Error() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-[612px] mt-0 relative w-[196px]" data-name="Error">
      <SwatchGroup />
      <SwatchGroup1 />
    </div>
  );
}

function Swatch4() {
  return (
    <div className="basis-0 bg-[#33618d] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[11px] text-white tracking-[0.5px]">
          <div className="flex flex-col justify-center leading-[16px] relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="mb-0">Primary</p>
            <p className="text-[11px]">&nbsp;</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-40</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch5() {
  return (
    <div className="bg-white h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#33618d] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-100</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup2() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch4 />
      <Swatch5 />
    </div>
  );
}

function Swatch6() {
  return (
    <div className="basis-0 bg-[#d0e4ff] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#154974] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Primary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch7() {
  return (
    <div className="bg-[#154974] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#d0e4ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup3() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch6 />
      <Swatch7 />
    </div>
  );
}

function Primary() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-0 mt-0 relative w-[196px]" data-name="Primary">
      <SwatchGroup2 />
      <SwatchGroup3 />
    </div>
  );
}

function Swatch8() {
  return (
    <div className="basis-0 bg-[#526070] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[11px] text-white tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Secondary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-40</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch9() {
  return (
    <div className="bg-white h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#526070] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-100</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup4() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch8 />
      <Swatch9 />
    </div>
  );
}

function Swatch10() {
  return (
    <div className="basis-0 bg-[#d6e4f7] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#3b4857] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Secondary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch11() {
  return (
    <div className="bg-[#3b4857] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#d6e4f7] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup5() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch10 />
      <Swatch11 />
    </div>
  );
}

function Secondary() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-[200px] mt-0 relative w-[196px]" data-name="Secondary">
      <SwatchGroup4 />
      <SwatchGroup5 />
    </div>
  );
}

function Swatch12() {
  return (
    <div className="basis-0 bg-[#7c580d] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[11px] text-white tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Tertiary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-40</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch13() {
  return (
    <div className="bg-white h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#7c580d] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-100</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup6() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch12 />
      <Swatch13 />
    </div>
  );
}

function Swatch14() {
  return (
    <div className="basis-0 bg-[#ffdeac] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#604100] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Tertiary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch15() {
  return (
    <div className="bg-[#604100] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#ffdeac] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup7() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch14 />
      <Swatch15 />
    </div>
  );
}

function Tertiary() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-[400px] mt-0 relative w-[196px]" data-name="Tertiary">
      <SwatchGroup6 />
      <SwatchGroup7 />
    </div>
  );
}

function PrimarySecondaryTertiary() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative" data-name="Primary Secondary Tertiary">
      <Primary />
      <Secondary />
      <Tertiary />
    </div>
  );
}

function TopRow() {
  return (
    <div className="basis-0 grid-cols-[max-content] grid-rows-[max-content] grow inline-grid leading-[0] min-h-px min-w-px place-items-start relative shrink-0 w-full" data-name="top row">
      <Error />
      <PrimarySecondaryTertiary />
    </div>
  );
}

function Swatch16() {
  return (
    <div className="[grid-area:1_/_1] bg-[#d0e4ff] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-0 mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#001d35] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Primary Fixed</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">P-90</p>
      </div>
    </div>
  );
}

function Swatch17() {
  return (
    <div className="[grid-area:1_/_1] bg-[#9ecafc] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-[98px] mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#154974] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Primary Fixed Dim</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">P-80</p>
      </div>
    </div>
  );
}

function BaseFixed() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="base fixed">
      <Swatch16 />
      <Swatch17 />
    </div>
  );
}

function Swatch18() {
  return (
    <div className="bg-[#001d35] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#d0e4ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary Fixed</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch19() {
  return (
    <div className="bg-[#154974] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#9ecafc] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary Fixed Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup8() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0" data-name="swatch group">
      <BaseFixed />
      <Swatch18 />
      <Swatch19 />
    </div>
  );
}

function Swatch20() {
  return (
    <div className="[grid-area:1_/_1] bg-[#d6e4f7] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-0 mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#0f1d2a] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Secondary Fixed</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">S-90</p>
      </div>
    </div>
  );
}

function Swatch21() {
  return (
    <div className="[grid-area:1_/_1] bg-[#bac8db] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-[98px] mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#3b4857] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Secondary Fixed Dim</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">S-80</p>
      </div>
    </div>
  );
}

function BaseFixed1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="base fixed">
      <Swatch20 />
      <Swatch21 />
    </div>
  );
}

function Swatch22() {
  return (
    <div className="bg-[#0f1d2a] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#d6e4f7] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary Fixed</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch23() {
  return (
    <div className="bg-[#3b4857] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#bac8db] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary Fixed Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup9() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0" data-name="swatch group">
      <BaseFixed1 />
      <Swatch22 />
      <Swatch23 />
    </div>
  );
}

function Swatch24() {
  return (
    <div className="[grid-area:1_/_1] bg-[#ffdeac] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-0 mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#281900] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Tertiary Fixed</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">T-90</p>
      </div>
    </div>
  );
}

function Swatch25() {
  return (
    <div className="[grid-area:1_/_1] bg-[#f0bf6d] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-[98px] mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#281900] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Tertiary Fixed Dim</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">T-80</p>
      </div>
    </div>
  );
}

function BaseFixed2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="base fixed">
      <Swatch24 />
      <Swatch25 />
    </div>
  );
}

function Swatch26() {
  return (
    <div className="bg-[#281900] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#ffdeac] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary Fixed</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch27() {
  return (
    <div className="bg-[#604100] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#f0bf6d] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary Fixed Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup10() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0" data-name="swatch group">
      <BaseFixed2 />
      <Swatch26 />
      <Swatch27 />
    </div>
  );
}

function FixedColors() {
  return (
    <div className="content-stretch flex gap-[4px] h-[128px] items-start relative shrink-0 w-[596px]" data-name="Fixed colors">
      <SwatchGroup8 />
      <SwatchGroup9 />
      <SwatchGroup10 />
    </div>
  );
}

function Swatch28() {
  return (
    <div className="basis-0 bg-[#d8dae0] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surface Dim</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-87</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch29() {
  return (
    <div className="basis-0 bg-[#f8f9ff] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-98</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch30() {
  return (
    <div className="basis-0 bg-[#f8f9ff] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surface Bright</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-98</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SurfaceGroup() {
  return (
    <div className="basis-0 content-stretch flex grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="Surface group">
      <Swatch28 />
      <Swatch29 />
      <Swatch30 />
    </div>
  );
}

function Swatch31() {
  return (
    <div className="basis-0 bg-white grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container Lowest</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-100</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch32() {
  return (
    <div className="basis-0 bg-[#f2f3f9] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container Low</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-96</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch33() {
  return (
    <div className="basis-0 bg-[#eceef4] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-94</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch34() {
  return (
    <div className="basis-0 bg-[#e6e8ee] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container High</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-92</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch35() {
  return (
    <div className="basis-0 bg-[#e0e2e8] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#191c20] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container Highest</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Surfaces() {
  return (
    <div className="basis-0 content-stretch flex grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="Surfaces">
      <Swatch31 />
      <Swatch32 />
      <Swatch33 />
      <Swatch34 />
      <Swatch35 />
    </div>
  );
}

function Swatch36() {
  return (
    <div className="basis-0 bg-[#191c20] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f8f9ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch37() {
  return (
    <div className="basis-0 bg-[#42474e] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f8f9ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Surface Var.</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">NV-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch38() {
  return (
    <div className="basis-0 bg-[#73777f] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f8f9ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Outline</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">NV-50</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch39() {
  return (
    <div className="basis-0 bg-[#c2c7cf] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#2d3135] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Outline Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">NV-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function OnSurfaces() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="on surfaces">
      <Swatch36 />
      <Swatch37 />
      <Swatch38 />
      <Swatch39 />
    </div>
  );
}

function Surfaces1() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-0 mt-0 relative w-[596px]" data-name="Surfaces">
      <SurfaceGroup />
      <Surfaces />
      <OnSurfaces />
    </div>
  );
}

function Swatch40() {
  return (
    <div className="basis-0 bg-[#2d3135] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#eff0f7] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Inverse Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-20</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch41() {
  return (
    <div className="bg-[#eff0f7] h-[38px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[38px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#2d3135] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Inverse On Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-95</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function InverseSurface() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="Inverse surface">
      <Swatch40 />
      <Swatch41 />
    </div>
  );
}

function Swatch42() {
  return (
    <div className="bg-[#9ecafc] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#154974] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Inverse Primary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Inverses() {
  return (
    <div className="basis-0 content-stretch flex flex-col gap-[4px] grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="inverses">
      <InverseSurface />
      <Swatch42 />
    </div>
  );
}

function Swatch43() {
  return (
    <div className="basis-0 bg-black grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f8f9ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Scrim</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-0</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch44() {
  return (
    <div className="basis-0 bg-black grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f8f9ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Shadow</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-0</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ScrimAndShadow() {
  return (
    <div className="content-stretch flex gap-[16px] h-[40px] items-start relative shrink-0 w-full" data-name="scrim and shadow">
      <Swatch43 />
      <Swatch44 />
    </div>
  );
}

function Other() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[16px] h-[186px] items-start justify-end ml-[612px] mt-0 relative w-[196px]" data-name="other">
      <Inverses />
      <ScrimAndShadow />
    </div>
  );
}

function BottomRow() {
  return (
    <div className="basis-0 grid-cols-[max-content] grid-rows-[max-content] grow inline-grid leading-[0] min-h-px min-w-px place-items-start relative shrink-0 w-full" data-name="bottom row">
      <Surfaces1 />
      <Other />
    </div>
  );
}

function Scheme() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[532px] items-start justify-end relative shrink-0 w-[808px]" data-name="scheme">
      <TopRow />
      <FixedColors />
      <BottomRow />
    </div>
  );
}

function Swatch45() {
  return (
    <div className="basis-0 bg-[#ffb4ab] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#690005] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Error</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch46() {
  return (
    <div className="bg-[#690005] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#ffb4ab] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Error</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup11() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch45 />
      <Swatch46 />
    </div>
  );
}

function Swatch47() {
  return (
    <div className="basis-0 bg-[#93000a] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#ffdad6] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Error Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch48() {
  return (
    <div className="bg-[#ffdad6] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#93000a] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Error Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">E-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup12() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch47 />
      <Swatch48 />
    </div>
  );
}

function Error1() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-[612px] mt-0 relative w-[196px]" data-name="Error">
      <SwatchGroup11 />
      <SwatchGroup12 />
    </div>
  );
}

function Swatch49() {
  return (
    <div className="basis-0 bg-[#9ecafc] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#003256] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center leading-[16px] relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="mb-0">Primary</p>
            <p className="text-[11px]">&nbsp;</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch50() {
  return (
    <div className="bg-[#003256] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#9ecafc] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-20</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup13() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch49 />
      <Swatch50 />
    </div>
  );
}

function Swatch51() {
  return (
    <div className="basis-0 bg-[#154974] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#d0e4ff] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Primary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch52() {
  return (
    <div className="bg-[#d0e4ff] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#154974] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup14() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch51 />
      <Swatch52 />
    </div>
  );
}

function Primary1() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-0 mt-0 relative w-[196px]" data-name="Primary">
      <SwatchGroup13 />
      <SwatchGroup14 />
    </div>
  );
}

function Swatch53() {
  return (
    <div className="basis-0 bg-[#bac8db] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#243140] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Secondary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch54() {
  return (
    <div className="bg-[#243140] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#bac8db] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-20</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup15() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch53 />
      <Swatch54 />
    </div>
  );
}

function Swatch55() {
  return (
    <div className="basis-0 bg-[#3b4857] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#d6e4f7] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Secondary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch56() {
  return (
    <div className="bg-[#d6e4f7] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#3b4857] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup16() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch55 />
      <Swatch56 />
    </div>
  );
}

function Secondary1() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-[200px] mt-0 relative w-[196px]" data-name="Secondary">
      <SwatchGroup15 />
      <SwatchGroup16 />
    </div>
  );
}

function Swatch57() {
  return (
    <div className="basis-0 bg-[#f0bf6d] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#432c00] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Tertiary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch58() {
  return (
    <div className="bg-[#432c00] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f0bf6d] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-20</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup17() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch57 />
      <Swatch58 />
    </div>
  );
}

function Swatch59() {
  return (
    <div className="basis-0 bg-[#604100] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#ffdeac] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Tertiary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch60() {
  return (
    <div className="bg-[#ffdeac] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#604100] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup18() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="swatch group">
      <Swatch59 />
      <Swatch60 />
    </div>
  );
}

function Tertiary1() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-[400px] mt-0 relative w-[196px]" data-name="Tertiary">
      <SwatchGroup17 />
      <SwatchGroup18 />
    </div>
  );
}

function PrimarySecondaryTertiary1() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative" data-name="Primary Secondary Tertiary">
      <Primary1 />
      <Secondary1 />
      <Tertiary1 />
    </div>
  );
}

function TopRow1() {
  return (
    <div className="basis-0 grid-cols-[max-content] grid-rows-[max-content] grow inline-grid leading-[0] min-h-px min-w-px place-items-start relative shrink-0 w-full" data-name="top row">
      <Error1 />
      <PrimarySecondaryTertiary1 />
    </div>
  );
}

function Swatch61() {
  return (
    <div className="[grid-area:1_/_1] bg-[#d0e4ff] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-0 mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#001d35] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Primary Fixed</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">P-90</p>
      </div>
    </div>
  );
}

function Swatch62() {
  return (
    <div className="[grid-area:1_/_1] bg-[#9ecafc] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-[98px] mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#154974] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Primary Fixed Dim</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">P-80</p>
      </div>
    </div>
  );
}

function BaseFixed3() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="base fixed">
      <Swatch61 />
      <Swatch62 />
    </div>
  );
}

function Swatch63() {
  return (
    <div className="bg-[#001d35] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#d0e4ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary Fixed</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch64() {
  return (
    <div className="bg-[#154974] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#9ecafc] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Primary Fixed Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup19() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0" data-name="swatch group">
      <BaseFixed3 />
      <Swatch63 />
      <Swatch64 />
    </div>
  );
}

function Swatch65() {
  return (
    <div className="[grid-area:1_/_1] bg-[#d6e4f7] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-0 mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#0f1d2a] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Secondary Fixed</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">S-90</p>
      </div>
    </div>
  );
}

function Swatch66() {
  return (
    <div className="[grid-area:1_/_1] bg-[#bac8db] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-[98px] mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#3b4857] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Secondary Fixed Dim</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">S-80</p>
      </div>
    </div>
  );
}

function BaseFixed4() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="base fixed">
      <Swatch65 />
      <Swatch66 />
    </div>
  );
}

function Swatch67() {
  return (
    <div className="bg-[#0f1d2a] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#d6e4f7] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary Fixed</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch68() {
  return (
    <div className="bg-[#3b4857] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#bac8db] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Secondary Fixed Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">S-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup20() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0" data-name="swatch group">
      <BaseFixed4 />
      <Swatch67 />
      <Swatch68 />
    </div>
  );
}

function Swatch69() {
  return (
    <div className="[grid-area:1_/_1] bg-[#ffdeac] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-0 mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#281900] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Tertiary Fixed</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">T-90</p>
      </div>
    </div>
  );
}

function Swatch70() {
  return (
    <div className="[grid-area:1_/_1] bg-[#f0bf6d] box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[56px] items-start justify-between ml-[98px] mt-0 pb-[12px] pt-[10px] px-[12px] relative text-[#604100] text-[11px] tracking-[0.5px] w-[98px]" data-name=".Swatch">
      <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">Tertiary Fixed Dim</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px]">T-80</p>
      </div>
    </div>
  );
}

function BaseFixed5() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="base fixed">
      <Swatch69 />
      <Swatch70 />
    </div>
  );
}

function Swatch71() {
  return (
    <div className="bg-[#281900] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#ffdeac] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary Fixed</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch72() {
  return (
    <div className="bg-[#604100] h-[36px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[36px] items-start justify-between leading-[0] px-[12px] py-[10px] relative text-[#f0bf6d] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Tertiary Fixed Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">T-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SwatchGroup21() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0" data-name="swatch group">
      <BaseFixed5 />
      <Swatch71 />
      <Swatch72 />
    </div>
  );
}

function FixedColors1() {
  return (
    <div className="content-stretch flex gap-[4px] h-[128px] items-start relative shrink-0 w-[596px]" data-name="Fixed colors">
      <SwatchGroup19 />
      <SwatchGroup20 />
      <SwatchGroup21 />
    </div>
  );
}

function Swatch73() {
  return (
    <div className="basis-0 bg-[#101418] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surface Dim</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-6</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch74() {
  return (
    <div className="basis-0 bg-[#101418] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-6</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch75() {
  return (
    <div className="basis-0 bg-[#36393e] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surface Bright</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-24</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SurfaceGroup1() {
  return (
    <div className="basis-0 content-stretch flex grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="Surface group">
      <Swatch73 />
      <Swatch74 />
      <Swatch75 />
    </div>
  );
}

function Swatch76() {
  return (
    <div className="basis-0 bg-[#0b0e12] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container Lowest</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-4</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch77() {
  return (
    <div className="basis-0 bg-[#191c20] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container Low</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-10</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch78() {
  return (
    <div className="basis-0 bg-[#1d2024] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-12</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch79() {
  return (
    <div className="basis-0 bg-[#272a2f] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container High</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-17</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch80() {
  return (
    <div className="basis-0 bg-[#32353a] grow h-full min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#e0e2e8] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Surf. Container Highest</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-22</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Surfaces2() {
  return (
    <div className="basis-0 content-stretch flex grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="Surfaces">
      <Swatch76 />
      <Swatch77 />
      <Swatch78 />
      <Swatch79 />
      <Swatch80 />
    </div>
  );
}

function Swatch81() {
  return (
    <div className="basis-0 bg-[#e0e2e8] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#101418] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch82() {
  return (
    <div className="basis-0 bg-[#c2c7cf] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#101418] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">On Surface Var.</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">NV-80</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch83() {
  return (
    <div className="basis-0 bg-[#8c9199] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#101418] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Outline</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">NV-60</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch84() {
  return (
    <div className="basis-0 bg-[#42474e] grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#e0e2e8] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Outline Variant</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">NV-30</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function OnSurfaces1() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="on surfaces">
      <Swatch81 />
      <Swatch82 />
      <Swatch83 />
      <Swatch84 />
    </div>
  );
}

function Surfaces3() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[4px] h-[186px] items-start ml-0 mt-0 relative w-[596px]" data-name="Surfaces">
      <SurfaceGroup1 />
      <Surfaces2 />
      <OnSurfaces1 />
    </div>
  );
}

function Swatch85() {
  return (
    <div className="basis-0 bg-[#e0e2e8] grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative size-full text-[#2d3135] text-[11px] tracking-[0.5px]">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Inverse Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-90</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch86() {
  return (
    <div className="bg-[#2d3135] h-[38px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[38px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#e0e2e8] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Inverse On Surface</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-20</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function InverseSurface1() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="Inverse surface">
      <Swatch85 />
      <Swatch86 />
    </div>
  );
}

function Swatch87() {
  return (
    <div className="bg-[#33618d] h-[40px] relative shrink-0 w-full" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#d0e4ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Inverse Primary</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">P-40</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Inverses1() {
  return (
    <div className="basis-0 content-stretch flex flex-col gap-[4px] grow items-start min-h-px min-w-px relative shrink-0 w-full" data-name="inverses">
      <InverseSurface1 />
      <Swatch87 />
    </div>
  );
}

function Swatch88() {
  return (
    <div className="basis-0 bg-black grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f8f9ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Scrim</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-0</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Swatch89() {
  return (
    <div className="basis-0 bg-black grow h-[40px] min-h-px min-w-px relative shrink-0" data-name=".Swatch">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col font-['Roboto:Medium',sans-serif] font-medium h-[40px] items-start justify-between leading-[0] pb-[12px] pt-[10px] px-[12px] relative text-[#f8f9ff] text-[11px] tracking-[0.5px] w-full">
          <div className="flex flex-col justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">Shadow</p>
          </div>
          <div className="flex flex-col justify-center relative shrink-0 text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[16px]">N-0</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ScrimAndShadow1() {
  return (
    <div className="content-stretch flex gap-[16px] h-[40px] items-start relative shrink-0 w-full" data-name="scrim and shadow">
      <Swatch88 />
      <Swatch89 />
    </div>
  );
}

function Other1() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col gap-[16px] h-[186px] items-start justify-end ml-[612px] mt-0 relative w-[196px]" data-name="other">
      <Inverses1 />
      <ScrimAndShadow1 />
    </div>
  );
}

function BottomRow1() {
  return (
    <div className="basis-0 grid-cols-[max-content] grid-rows-[max-content] grow inline-grid leading-[0] min-h-px min-w-px place-items-start relative shrink-0 w-full" data-name="bottom row">
      <Surfaces3 />
      <Other1 />
    </div>
  );
}

function Scheme1() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[532px] items-start justify-end relative shrink-0 w-[808px]" data-name="scheme">
      <TopRow1 />
      <FixedColors1 />
      <BottomRow1 />
    </div>
  );
}

function SchematicGroup() {
  return (
    <div className="absolute content-stretch flex gap-[80px] items-center left-[1126px] top-[233px]" data-name="Schematic group">
      <Scheme />
      <Scheme1 />
    </div>
  );
}

function Frame() {
  return (
    <div className="box-border content-stretch flex flex-col gap-[10px] items-start p-[152.5px] relative shrink-0 w-[2999px]">
      <MaterialTheme />
      <SchematicGroup />
    </div>
  );
}

export default function ColorGuidance() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-bl-[16px] rounded-br-[16px] rounded-tl-[80px] rounded-tr-[80px] size-full" data-name="Color Guidance">
      <Header />
      <Frame />
    </div>
  );
}