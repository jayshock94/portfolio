import svgPaths from "./svg-ls9jjnqlw1";
import imgMedia from "figma:asset/17e0d07e88478f6c7149bb8400b5e04c71c2193d.png";
import imgIPhone16ProBlackTitaniumPortrait from "figma:asset/85a8d4cb5dd8334894f69f8c4156fea900e1fc9a.png";

function Chrome() {
  return <div className="absolute backdrop-blur-[25px] backdrop-filter bg-[#fff8f7] inset-0" data-name="Chrome" />;
}

function Time() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0" data-name="Time">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center pl-[16px] pr-[6px] py-0 relative w-full">
          <p className="font-['SF_Pro:Semibold',sans-serif] font-[590] leading-[22px] relative shrink-0 text-[17px] text-black text-center text-nowrap whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
            9:41
          </p>
        </div>
      </div>
    </div>
  );
}

function DynamicIslandSpacer() {
  return <div className="h-[10px] shrink-0 w-[124px]" data-name="Dynamic Island spacer" />;
}

function Battery() {
  return (
    <div className="h-[13px] relative shrink-0 w-[27.328px]" data-name="Battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 13">
        <g id="Battery">
          <rect height="12" id="Border" opacity="0.35" rx="3.8" stroke="var(--stroke-0, black)" width="24" x="0.5" y="0.5" />
          <path d={svgPaths.p3bbd9700} fill="var(--fill-0, black)" id="Cap" opacity="0.4" />
          <rect fill="var(--fill-0, black)" height="9" id="Capacity" rx="2.5" width="21" x="2" y="2" />
        </g>
      </svg>
    </div>
  );
}

function Levels() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0" data-name="Levels">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex gap-[7px] items-center justify-center pl-[6px] pr-[16px] py-0 relative w-full">
          <div className="h-[12.226px] relative shrink-0 w-[19.2px]" data-name="Cellular Connection">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(0, 0, 0, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 13">
                <path clipRule="evenodd" d={svgPaths.p1e09e400} fill="var(--fill-0, black)" fillRule="evenodd" id="Cellular Connection" />
              </svg>
            </div>
          </div>
          <div className="h-[12.328px] relative shrink-0 w-[17.142px]" data-name="Wifi">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(0, 0, 0, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 13">
                <path clipRule="evenodd" d={svgPaths.p18b35300} fill="var(--fill-0, black)" fillRule="evenodd" id="Wifi" />
              </svg>
            </div>
          </div>
          <Battery />
        </div>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Frame">
      <Time />
      <DynamicIslandSpacer />
      <Levels />
    </div>
  );
}

function StatusBarIPhone() {
  return (
    <div className="box-border content-stretch flex flex-col h-[54px] items-start pb-0 pt-[21px] px-0 relative shrink-0 w-[402px]" data-name="Status Bar - iPhone">
      <Frame />
    </div>
  );
}

function NavigationBar() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Navigation Bar">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Chrome />
      </div>
      <div aria-hidden="true" className="absolute border-[0px_0px_0.333px] border-[rgba(0,0,0,0.3)] border-solid inset-0 pointer-events-none" />
      <StatusBarIPhone />
    </div>
  );
}

function Group1() {
  return (
    <div className="h-[23.161px] relative shrink-0 w-[147px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 147 24">
        <g id="Group 2">
          <path d={svgPaths.p2e2d1880} fill="var(--fill-0, #C21F32)" id="Vector" />
          <path d={svgPaths.p32c1c500} fill="var(--fill-0, #291715)" id="Vector_2" />
          <path d={svgPaths.p107be480} fill="var(--fill-0, #291715)" id="Vector_3" />
          <path d={svgPaths.p29a9c100} fill="var(--fill-0, #291715)" id="Vector_4" />
          <path d={svgPaths.p290b2740} fill="var(--fill-0, #291715)" id="Vector_5" />
          <path d={svgPaths.pbd27630} fill="var(--fill-0, #A7A9AC)" id="Vector_6" />
          <path d={svgPaths.p7eaef00} fill="var(--fill-0, #A7A9AC)" id="Vector_7" />
          <path d={svgPaths.p27e45400} fill="var(--fill-0, #A7A9AC)" id="Vector_8" />
          <path d={svgPaths.p223f5700} fill="var(--fill-0, #A7A9AC)" id="Vector_9" />
          <path d={svgPaths.pb353910} fill="var(--fill-0, #291715)" id="Vector_10" />
          <path d={svgPaths.pb5cf400} fill="var(--fill-0, #291715)" id="Vector_11" />
          <path d={svgPaths.p17a2ecc0} fill="var(--fill-0, #291715)" id="Vector_12" />
          <path d={svgPaths.p36a752f0} fill="var(--fill-0, #291715)" id="Vector_13" />
          <path d={svgPaths.p39586800} fill="var(--fill-0, #291715)" id="Vector_14" />
          <path d={svgPaths.p4b27a00} fill="var(--fill-0, #291715)" id="Vector_15" />
          <path d={svgPaths.p3af98100} fill="var(--fill-0, #291715)" id="Vector_16" />
          <path d={svgPaths.p399aff00} fill="var(--fill-0, #291715)" id="Vector_17" />
          <path d={svgPaths.p22968480} fill="var(--fill-0, #291715)" id="Vector_18" />
          <path d={svgPaths.pb035700} fill="var(--fill-0, #291715)" id="Vector_19" />
          <path d={svgPaths.p15432500} fill="var(--fill-0, #291715)" id="Vector_20" />
          <path d={svgPaths.p1b24bc00} fill="var(--fill-0, #291715)" id="Vector_21" />
          <path d={svgPaths.p1b84f800} fill="var(--fill-0, #291715)" id="Vector_22" />
          <path d={svgPaths.p88be200} fill="var(--fill-0, #291715)" id="Vector_23" />
          <path d={svgPaths.p26bb5a00} fill="var(--fill-0, #291715)" id="Vector_24" />
          <path d={svgPaths.p2ab96980} fill="var(--fill-0, #291715)" id="Vector_25" />
          <path d={svgPaths.p38795e30} fill="var(--fill-0, #291715)" id="Vector_26" />
          <path d={svgPaths.pd18e400} fill="var(--fill-0, #291715)" id="Vector_27" />
        </g>
      </svg>
    </div>
  );
}

function LeadingIcon() {
  return (
    <div className="basis-0 content-stretch flex flex-col gap-[10px] grow items-start min-h-px min-w-px relative shrink-0" data-name="leading-icon">
      <Group1 />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p23185c80} fill="var(--fill-0, #5E3F3C)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function StateLayer() {
  return (
    <div className="box-border content-stretch flex gap-[10px] items-center justify-center p-[8px] relative shrink-0" data-name="state-layer">
      <Icon />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[10px] items-center justify-center overflow-clip relative rounded-[100px] shrink-0" data-name="container">
      <StateLayer />
    </div>
  );
}

function TrailingIcon1() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-center justify-center relative shrink-0 size-[48px]" data-name="trailing-icon 1">
      <Container />
    </div>
  );
}

function TrailingIcon() {
  return (
    <div className="content-stretch flex h-[48px] items-center justify-end relative shrink-0" data-name="trailing-icon">
      <TrailingIcon1 />
    </div>
  );
}

function TopAppBar() {
  return (
    <div className="basis-0 bg-[#fff8f7] grow h-[64px] min-h-px min-w-px relative shrink-0" data-name="Top app bar">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[4px] h-[64px] items-center pl-[24px] pr-[16px] py-[8px] relative w-full">
          <LeadingIcon />
          <TrailingIcon />
        </div>
      </div>
    </div>
  );
}

function TopAppBar1() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="Top app bar">
      <TopAppBar />
    </div>
  );
}

function Group() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <div className="[grid-area:1_/_1] h-[23px] ml-0 mt-0 relative w-[256px]">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(255, 215, 209, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 256 23">
            <path d={svgPaths.pfb609f0} fill="var(--fill-0, #FFD7D1)" id="Rectangle 2" />
          </svg>
        </div>
      </div>
      <div className="[grid-area:1_/_1] flex flex-col font-['Playfair_Display:Medium',sans-serif] font-medium justify-center ml-[125px] mt-[11.5px] relative text-[#8d140b] text-[10px] text-center text-nowrap tracking-[0.1px] translate-x-[-50%] translate-y-[-50%]">
        <p className="leading-[20px] whitespace-pre">Start the Year Strong. Finance Your Dreams.</p>
      </div>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents font-['Raleway:Bold',sans-serif] font-bold leading-[0] left-[20px] text-center text-nowrap top-[-3px] tracking-[0.1px]">
      <div className="absolute flex flex-col justify-center left-[117.5px] text-[#ffd7d1] text-[20px] top-[17.5px] translate-x-[-50%] translate-y-[-50%]">
        <p className="leading-[41px] text-nowrap whitespace-pre">Drive Now, Pay Less.</p>
      </div>
      <div className="absolute flex flex-col justify-center left-[116.5px] text-[0px] text-white top-[58.5px] translate-x-[-50%] translate-y-[-50%]">
        <p className="leading-[41px] text-nowrap whitespace-pre">
          <span className="text-[48px]">{`3.0% `}</span>
          <span className="text-[16px]">APR</span>
        </p>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="h-[79px] relative shrink-0 w-[234px]">
      <Group2 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#8d140b] h-[188px] relative rounded-[12px] shadow-[0px_4px_8px_3px_rgba(0,0,0,0.15),0px_1px_3px_0px_rgba(0,0,0,0.3)] shrink-0 w-full">
      <div className="flex flex-col items-center size-full">
        <div className="box-border content-stretch flex flex-col h-[188px] items-center justify-between px-[24px] py-[16px] relative w-full">
          <Group />
          <Frame6 />
          <div className="flex flex-col font-['Playfair_Display:Medium',sans-serif] font-medium justify-center leading-[0] min-w-full relative shrink-0 text-[#ffd7d1] text-[10px] text-center tracking-[0.1px] w-[min-content]">
            <p className="leading-[20px]">Now until Feb 1</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Source_Serif_4:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#291715] text-[32px] text-nowrap">
        <p className="leading-[40px] whitespace-pre">Good afternoon, John</p>
      </div>
      <Frame7 />
    </div>
  );
}

function Text() {
  return (
    <div className="basis-0 content-stretch flex flex-col gap-[4px] grow items-start min-h-px min-w-px relative shrink-0 text-[#291715]" data-name="Text">
      <p className="font-['Figtree:Medium',sans-serif] font-medium leading-[24px] relative shrink-0 text-[16px] tracking-[0.15px] w-full">Apply for a loan</p>
      <p className="font-['Figtree:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[14px] tracking-[0.25px] w-full">Apply now</p>
    </div>
  );
}

function Content() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="Content">
      <div className="flex flex-row items-center size-full">
        <div className="box-border content-stretch flex gap-[16px] items-center p-[16px] relative size-full">
          <Text />
        </div>
      </div>
    </div>
  );
}

function Media() {
  return (
    <div className="h-full pointer-events-none relative shrink-0 w-[80px]" data-name="Media">
      <div aria-hidden="true" className="absolute border-[#e8bcb8] border-[1px_1px_1px_0px] border-solid inset-0" />
      <div className="absolute inset-0 overflow-hidden">
        <img alt="" className="absolute h-[127.71%] left-[-8.75%] max-w-none top-[-13.86%] w-[117.5%]" src={imgMedia} />
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="basis-0 content-stretch flex grow items-center min-h-px min-w-px overflow-clip relative rounded-[12px] shrink-0 z-[2]" data-name="Content">
      <div className="basis-0 flex flex-row grow items-center self-stretch shrink-0">
        <Content />
      </div>
      <div className="flex flex-row items-center self-stretch">
        <Media />
      </div>
    </div>
  );
}

function Background() {
  return <div className="absolute bg-[#fff0ef] inset-0 overflow-clip rounded-[12px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.3),0px_1px_3px_1px_rgba(0,0,0,0.15)] z-[1]" data-name="Background" />;
}

function HorizontalCard() {
  return (
    <div className="content-stretch flex isolate items-start relative rounded-[12px] shrink-0 w-full" data-name="Horizontal card">
      <Content1 />
      <Background />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col gap-[32px] items-start relative shrink-0 w-full">
      <Frame12 />
      <HorizontalCard />
    </div>
  );
}

function DirectionsCar() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="directions_car">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="directions_car">
          <mask height="24" id="mask0_3_3919" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="24" x="0" y="0">
            <rect fill="var(--fill-0, #D9D9D9)" height="24" id="Bounding box" width="24" />
          </mask>
          <g mask="url(#mask0_3_3919)">
            <path d={svgPaths.pecfae00} fill="var(--fill-0, #005186)" id="directions_car_2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0 w-full">
      <DirectionsCar />
      <div className="flex flex-col font-['Figtree:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#534341] text-[14px] text-center text-nowrap tracking-[0.1px]">
        <p className="leading-[20px] whitespace-pre">2021 Jeep Rubicon 1234</p>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="box-border content-stretch flex gap-[8px] items-center leading-[0] px-[30px] py-0 relative shrink-0">
      <div className="flex flex-col font-['Figtree:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#291715] text-[22px] text-nowrap">
        <p className="leading-[28px] whitespace-pre">$15,000.35</p>
      </div>
      <div className="basis-0 flex flex-col font-['Figtree:Medium',sans-serif] font-medium grow justify-center min-h-px min-w-px relative shrink-0 text-[#936e6a] text-[11px] tracking-[0.5px]">
        <p className="leading-[16px]">Current balance</p>
      </div>
    </div>
  );
}

function AccountSlot() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 z-[2]" data-name="Account slot">
      <Frame1 />
      <Frame4 />
    </div>
  );
}

function Background1() {
  return <div className="absolute bg-white inset-0 overflow-clip rounded-[12px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.3),0px_1px_3px_1px_rgba(0,0,0,0.15)] z-[1]" data-name="Background" />;
}

function HorizontalCardAccounts() {
  return (
    <div className="h-[84px] relative rounded-[12px] shrink-0 w-full" data-name="Horizontal card/Accounts">
      <div className="size-full">
        <div className="box-border content-stretch flex h-[84px] isolate items-start p-[16px] relative w-full">
          <AccountSlot />
          <Background1 />
        </div>
      </div>
    </div>
  );
}

function Home() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="home">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="home">
          <mask height="24" id="mask0_3_3970" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="24" x="0" y="0">
            <rect fill="var(--fill-0, #D9D9D9)" height="24" id="Bounding box" width="24" />
          </mask>
          <g mask="url(#mask0_3_3970)">
            <path d={svgPaths.p13572800} fill="var(--fill-0, #A50011)" id="home_2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0 w-full">
      <Home />
      <div className="flex flex-col font-['Figtree:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#534341] text-[14px] text-center text-nowrap tracking-[0.1px]">
        <p className="leading-[20px] whitespace-pre">801 Monroe St 8250</p>
      </div>
    </div>
  );
}

function Frame10() {
  return (
    <div className="box-border content-stretch flex gap-[8px] items-center leading-[0] px-[30px] py-0 relative shrink-0">
      <div className="flex flex-col font-['Figtree:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#291715] text-[22px] text-nowrap">
        <p className="leading-[28px] whitespace-pre">$264,376.87</p>
      </div>
      <div className="basis-0 flex flex-col font-['Figtree:Medium',sans-serif] font-medium grow justify-center min-h-px min-w-px relative shrink-0 text-[#936e6a] text-[11px] tracking-[0.5px]">
        <p className="leading-[16px]">Current balance</p>
      </div>
    </div>
  );
}

function AccountSlot1() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 z-[2]" data-name="Account slot">
      <Frame2 />
      <Frame10 />
    </div>
  );
}

function Background2() {
  return <div className="absolute bg-white inset-0 overflow-clip rounded-[12px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.3),0px_1px_3px_1px_rgba(0,0,0,0.15)] z-[1]" data-name="Background" />;
}

function HorizontalCardAccounts1() {
  return (
    <div className="h-[84px] relative rounded-[12px] shrink-0 w-full" data-name="Horizontal card/Accounts">
      <div className="size-full">
        <div className="box-border content-stretch flex h-[84px] isolate items-start p-[16px] relative w-full">
          <AccountSlot1 />
          <Background2 />
        </div>
      </div>
    </div>
  );
}

function AccountCircle() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="account_circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="account_circle">
          <mask height="24" id="mask0_3_3910" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="24" x="0" y="0">
            <rect fill="var(--fill-0, #D9D9D9)" height="24" id="Bounding box" width="24" />
          </mask>
          <g mask="url(#mask0_3_3910)">
            <path d={svgPaths.p8ea680} fill="var(--fill-0, #775654)" id="account_circle_2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0 w-full">
      <AccountCircle />
      <div className="flex flex-col font-['Figtree:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#534341] text-[14px] text-center text-nowrap tracking-[0.1px]">
        <p className="leading-[20px] whitespace-pre">Personal loan 2275</p>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="box-border content-stretch flex gap-[8px] items-center leading-[0] px-[30px] py-0 relative shrink-0">
      <div className="flex flex-col font-['Figtree:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#291715] text-[22px] text-nowrap">
        <p className="leading-[28px] whitespace-pre">$9,167.33</p>
      </div>
      <div className="basis-0 flex flex-col font-['Figtree:Medium',sans-serif] font-medium grow justify-center min-h-px min-w-px relative shrink-0 text-[#936e6a] text-[11px] tracking-[0.5px]">
        <p className="leading-[16px]">Current balance</p>
      </div>
    </div>
  );
}

function AccountSlot2() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px relative shrink-0 z-[2]" data-name="Account slot">
      <Frame3 />
      <Frame11 />
    </div>
  );
}

function Background3() {
  return <div className="absolute bg-white inset-0 overflow-clip rounded-[12px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.3),0px_1px_3px_1px_rgba(0,0,0,0.15)] z-[1]" data-name="Background" />;
}

function HorizontalCardAccounts2() {
  return (
    <div className="h-[84px] relative rounded-[12px] shrink-0 w-full" data-name="Horizontal card/Accounts">
      <div className="size-full">
        <div className="box-border content-stretch flex h-[84px] isolate items-start p-[16px] relative w-full">
          <AccountSlot2 />
          <Background3 />
        </div>
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Source_Serif_4:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#291715] text-[28px] w-full">
        <p className="leading-[36px]">Accounts</p>
      </div>
      <HorizontalCardAccounts />
      <HorizontalCardAccounts1 />
      <HorizontalCardAccounts2 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="h-[812px] relative shrink-0 w-full">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[32px] h-[812px] items-start px-[32px] py-[24px] relative w-full">
          <Frame9 />
          <Frame8 />
        </div>
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow items-center min-h-px min-w-px relative shrink-0">
      <TopAppBar1 />
      <Frame5 />
    </div>
  );
}

function IPhone16ProMaxHome() {
  return (
    <div className="basis-0 bg-[#fff8f7] content-stretch flex gap-[10px] grow items-start min-h-px min-w-px overflow-x-clip overflow-y-auto relative shrink-0 w-full" data-name="iPhone 16 Pro Max/Home">
      <Frame13 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <mask height="24" id="mask0_3_3906" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="24" x="0" y="0">
            <rect fill="var(--fill-0, #D9D9D9)" height="24" id="Bounding box" width="24" />
          </mask>
          <g mask="url(#mask0_3_3906)">
            <path d={svgPaths.p200c1500} fill="var(--fill-0, #A50011)" id="home" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function StateLayer1() {
  return (
    <div className="box-border content-stretch flex h-[32px] items-center justify-center px-[20px] py-[4px] relative shrink-0 w-[64px]" data-name="state-layer">
      <Icon1 />
    </div>
  );
}

function IconContainer() {
  return (
    <div className="bg-[#ffd7d1] content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[16px] shrink-0" data-name="icon-container">
      <StateLayer1 />
    </div>
  );
}

function NavItem() {
  return (
    <div className="basis-0 box-border content-stretch flex flex-col gap-[4px] grow items-center justify-center min-h-px min-w-px pb-[16px] pt-[12px] px-0 relative shrink-0" data-name="Nav item 1">
      <IconContainer />
      <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] min-w-full relative shrink-0 text-[#291715] text-[12px] text-center tracking-[0.5px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Home
      </p>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <mask height="24" id="mask0_3_3923" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="24" x="0" y="0">
            <rect fill="var(--fill-0, #D9D9D9)" height="24" id="Bounding box" width="24" />
          </mask>
          <g mask="url(#mask0_3_3923)">
            <path d={svgPaths.pc8ca800} fill="var(--fill-0, #534341)" id="credit_card" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function StateLayer2() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[32px] items-center justify-center px-[20px] py-[4px] relative shrink-0 w-[64px]" data-name="state-layer">
      <Icon2 />
    </div>
  );
}

function IconContainer1() {
  return (
    <div className="content-stretch flex items-center justify-center relative rounded-[16px] shrink-0 w-[32px]" data-name="icon-container">
      <StateLayer2 />
    </div>
  );
}

function NavItem1() {
  return (
    <button className="basis-0 box-border content-stretch cursor-pointer flex flex-col gap-[4px] grow items-center justify-center min-h-px min-w-px pb-[16px] pt-[12px] px-0 relative shrink-0" data-name="Nav item 2">
      <IconContainer1 />
      <p className="font-['Figtree:Medium',sans-serif] font-medium leading-[16px] min-w-full relative shrink-0 text-[#534341] text-[12px] text-center tracking-[0.5px] w-[min-content]">Pay</p>
    </button>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <mask height="24" id="mask0_3_3899" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="24" x="0" y="0">
            <rect fill="var(--fill-0, #D9D9D9)" height="24" id="Bounding box" width="24" />
          </mask>
          <g mask="url(#mask0_3_3899)">
            <path d={svgPaths.p220da280} fill="var(--fill-0, #534341)" id="help" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function StateLayer3() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[32px] items-center justify-center px-[20px] py-[4px] relative shrink-0 w-[64px]" data-name="state-layer">
      <Icon3 />
    </div>
  );
}

function IconContainer2() {
  return (
    <div className="content-stretch flex items-center justify-center relative rounded-[16px] shrink-0 w-[32px]" data-name="icon-container">
      <StateLayer3 />
    </div>
  );
}

function NavItem2() {
  return (
    <div className="basis-0 box-border content-stretch flex flex-col gap-[4px] grow items-center justify-center min-h-px min-w-px pb-[16px] pt-[12px] px-0 relative shrink-0" data-name="Nav item 3">
      <IconContainer2 />
      <p className="font-['Figtree:Medium',sans-serif] font-medium leading-[16px] min-w-full relative shrink-0 text-[#534341] text-[12px] text-center tracking-[0.5px] w-[min-content]">Help</p>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p5910600} fill="var(--fill-0, #534341)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function StateLayer4() {
  return (
    <div className="box-border content-stretch flex gap-[10px] h-[32px] items-center justify-center px-[20px] py-[4px] relative shrink-0 w-[64px]" data-name="state-layer">
      <Icon4 />
    </div>
  );
}

function IconContainer3() {
  return (
    <div className="content-stretch flex items-center justify-center relative rounded-[16px] shrink-0 w-[32px]" data-name="icon-container">
      <StateLayer4 />
    </div>
  );
}

function NavItem3() {
  return (
    <div className="basis-0 box-border content-stretch flex flex-col gap-[4px] grow items-center justify-center min-h-px min-w-px pb-[16px] pt-[12px] px-0 relative shrink-0" data-name="Nav item 4">
      <IconContainer3 />
      <p className="font-['Figtree:Medium',sans-serif] font-medium leading-[16px] min-w-full relative shrink-0 text-[#534341] text-[12px] text-center tracking-[0.5px] w-[min-content]">More</p>
    </div>
  );
}

function NavigationBar1() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="Navigation bar">
      <div className="size-full">
        <div className="box-border content-stretch flex gap-[8px] items-start px-[8px] py-0 relative size-full">
          <NavItem />
          <NavItem1 />
          <NavItem2 />
          <NavItem3 />
        </div>
      </div>
    </div>
  );
}

function NavigationBar2() {
  return (
    <div className="basis-0 bg-[#fff0ef] content-stretch flex grow h-[80px] items-start justify-center min-h-px min-w-px relative shrink-0" data-name="Navigation bar">
      <NavigationBar1 />
    </div>
  );
}

function PrototypeNavigationBar() {
  return (
    <div className="bg-[#fff0ef] content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Prototype/navigation bar">
      <NavigationBar2 />
    </div>
  );
}

function Contents() {
  return (
    <div className="absolute content-stretch flex flex-col h-[874px] items-center left-0 overflow-clip right-0 rounded-[44px] top-0" data-name="Contents">
      <NavigationBar />
      <IPhone16ProMaxHome />
      <PrototypeNavigationBar />
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-0 right-0" data-name="Home Indicator">
      <div className="absolute bottom-[8px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[144px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-black h-[5px] rounded-[100px] w-[144px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

function Bezel() {
  return (
    <div className="absolute h-[874px] left-0 top-0 w-[402px]" data-name="Bezel">
      <div className="absolute h-[920px] left-[-24px] top-[-23px] w-[450px]" data-name="iPhone 16 Pro - Black Titanium - Portrait">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgIPhone16ProBlackTitaniumPortrait} />
      </div>
    </div>
  );
}

export default function Home1() {
  return (
    <div className="overflow-clip relative rounded-[36px] size-full" data-name="Home">
      <Contents />
      <HomeIndicator />
      <Bezel />
    </div>
  );
}