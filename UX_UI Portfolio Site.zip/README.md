
  # UX/UI Portfolio Site

  This is a code bundle for UX/UI Portfolio Site. The original project is available at https://www.figma.com/design/9pfII5wfwMGIhf8xdJmXtM/UX-UI-Portfolio-Site.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  